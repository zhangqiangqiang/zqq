function proof(dataset){
	var record = CreditCardProof_dataset.getFirstRecord();
	while(record){
		var proofName = record.getValue("proofName");
		var proofPath = record.getValue("proofPath");
		var getTime = record.getValue("getTime");
		var html = "<li><div class='deatil'><h2>"+proofName+"</h2><p>获取时间：<br/>"+
			getTime+"</p><a href='Javascript:void(0);' onClick=\"Javascript:downloadfile('"+proofName+"')\">下载凭证</a></div><img src='"+proofPath+proofName+"'/></li>"
		$("#proof-ul").append(html);
		record=record.getNextRecord();
	}
}
