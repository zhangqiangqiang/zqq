package com.huateng.hsbc.creditcard.update;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.huateng.commquery.result.MultiUpdateResultBean;
import com.huateng.commquery.result.UpdateResultBean;
import com.huateng.commquery.result.UpdateReturnBean;
import com.huateng.ebank.framework.operation.OPCaller;
import com.huateng.ebank.framework.operation.OperationContext;
import com.huateng.ebank.framework.web.commQuery.BaseUpdate;
import com.huateng.exception.AppException;
import com.huateng.hsbc.creditcard.bean.CreditCardAlert;
import com.huateng.hsbc.creditcard.operation.ModOperation;

public class ModUpdate extends BaseUpdate{
	private static final String DATASET_ID="CreditCardDtl";
	
	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean paramMultiUpdateResultBean,
			HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
			throws AppException {
		
		UpdateReturnBean updateReturnBean = new UpdateReturnBean();
		UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID(DATASET_ID);
		CreditCardAlert alert = new CreditCardAlert();
		if (updateResultBean.hasNext()) {
			Map map = updateResultBean.next();
			mapToObject(alert, map);
		}
		
		OperationContext oc = new OperationContext();
		oc.setAttribute(ModOperation.MOD_BEAN, alert);
		OPCaller.call(ModOperation.ID, oc);
		return updateReturnBean;
	}

}
