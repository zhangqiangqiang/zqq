package com.huateng.hsbc.creditcard.update;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.huateng.commquery.result.MultiUpdateResultBean;
import com.huateng.commquery.result.UpdateResultBean;
import com.huateng.commquery.result.UpdateReturnBean;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.web.commQuery.BaseUpdate;
import com.huateng.exception.AppException;
import com.huateng.hsbc.creditcard.bean.CreditCardAlert;
import com.huateng.hsbc.creditcard.bean.CreditCardProof;
import com.huateng.hsbc.creditcard.utils.CreditCommUtils;
import com.huateng.hsbc.creditcard.utils.SftpUtils;
import com.huateng.report.utils.ReportUtils;

public class GetProofUpdate extends BaseUpdate{
	private static final String DATASET_ID="CreditCardDtl";
	
	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean paramMultiUpdateResultBean,
			HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
			throws AppException {
		
		UpdateReturnBean updateReturnBean = new UpdateReturnBean();
		UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID(DATASET_ID);
		CreditCardAlert alert = new CreditCardAlert();
		if (updateResultBean.hasNext()) {
			Map map = updateResultBean.next();
			mapToObject(alert, map);
		}
		
		String lpath = ReportUtils.getSysParamsValue("PROOF", "LPATH");
		String ip = ReportUtils.getSysParamsValue("PROOF", "IP");
		String port = ReportUtils.getSysParamsValue("PROOF", "PORT");
		String username = ReportUtils.getSysParamsValue("PROOF", "USERNAME");
		String pwd = ReportUtils.getSysParamsValue("PROOF", "PASSWORD");
		String prikey = ReportUtils.getSysParamsValue("PROOF", "PRIKEY");
		String path = ReportUtils.getSysParamsValue("PROOF", "PATH");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		SftpUtils sftp = new SftpUtils(ip,port,username,pwd,prikey);
		try {
			List<String> fileNames = sftp.download(path, lpath, alert.getAlarmNo());
			if(fileNames.size()>0){
				updateReturnBean.setParameter("flag", "1");
				String delSql = "delete from CREDIT_CARD_PROOF a where ALARM_NO = ?";
				rootdao.executeSqlWithPara(delSql, new String[]{alert.getAlarmNo()});
			}else{
				updateReturnBean.setParameter("flag", "0");
			}
			for(String fileName:fileNames){
				CreditCardProof proof = new CreditCardProof();
				proof.setId(CreditCommUtils.getUUID());
				proof.setAlarmNo(alert.getAlarmNo());
				proof.setMainId(alert.getId());
				proof.setProofName(fileName);
				proof.setProofPath(lpath);
				proof.setGetTime(sdf.format(new Date()));
				rootdao.saveOrUpdate(proof);
			}
		} catch (Exception e) {
			updateReturnBean.setParameter("flag", "2");
			e.printStackTrace();
		}
		return updateReturnBean;
	}

}
