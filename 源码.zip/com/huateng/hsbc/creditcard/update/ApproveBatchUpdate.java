package com.huateng.hsbc.creditcard.update;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.huateng.commquery.result.MultiUpdateResultBean;
import com.huateng.commquery.result.UpdateResultBean;
import com.huateng.commquery.result.UpdateReturnBean;
import com.huateng.ebank.framework.operation.OPCaller;
import com.huateng.ebank.framework.operation.OperationContext;
import com.huateng.ebank.framework.web.commQuery.BaseUpdate;
import com.huateng.exception.AppException;
import com.huateng.hsbc.creditcard.operation.ApproveOperation;

public class ApproveBatchUpdate extends BaseUpdate{
	private static final String DATASET_ID="CreditCardExtractApproveInfo";
	
	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean paramMultiUpdateResultBean,
			HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
			throws AppException {
		
		UpdateReturnBean updateReturnBean = new UpdateReturnBean();
		UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID(DATASET_ID);
		String ids = updateResultBean.getParameter("ids");
		String approveStatusChoose = updateResultBean.getParameter("approveStatusChoose");
        String approveMemoChoose = updateResultBean.getParameter("approveMemoChoose");
		
		OperationContext oc = new OperationContext();
		oc.setAttribute(ApproveOperation.IDS, ids);
		oc.setAttribute(ApproveOperation.APPROVE_STATUS, approveStatusChoose);
		oc.setAttribute(ApproveOperation.APPROVE_MEMO, approveMemoChoose);
		OPCaller.call(ApproveOperation.ID, oc);
		return updateReturnBean;
	}

}
