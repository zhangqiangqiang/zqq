package com.huateng.hsbc.creditcard.update;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.huateng.commquery.result.MultiUpdateResultBean;
import com.huateng.commquery.result.UpdateResultBean;
import com.huateng.commquery.result.UpdateReturnBean;
import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.web.commQuery.BaseUpdate;
import com.huateng.exception.AppException;
import com.huateng.hsbc.creditcard.bean.CreditCardAlert;
import com.huateng.hsbc.creditcard.utils.CreditConstant;
import com.huateng.report.hf.aml.utils.HsbcAmlBizLogUtils;

public class AssignUpdate extends BaseUpdate{
	private static final String DATASET_ID="CreditCardAssignInfo";
	
	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean paramMultiUpdateResultBean,
			HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
			throws AppException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		UpdateReturnBean updateReturnBean = new UpdateReturnBean();
		UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID(DATASET_ID);
		
		String selectTlrno = updateResultBean.getParameter("selectTlrno");
		
		int num = 0;
		while (updateResultBean.hasNext()) {
			Map map = updateResultBean.next();
			String select = (String) map.get("select");
			if(select!=null&&"true".equals(select)){
				CreditCardAlert alert = new CreditCardAlert();
				mapToObject(alert, map);
				String id = alert.getId();
				//两种情况 1.REC_STATUS=00 2.REC_STATUS<>00 已经分派过的
				String recStatus = alert.getRecStatus();
				if(CreditConstant.RecStatus.STATUS_00.getValue().equals(recStatus)){
					String sql=" UPDATE CREDIT_CARD_ALERT SET OPERATOR_TLR = ? , REC_STATUS='01' , OPEN_ALERT_TIME = ? WHERE REC_ID = ? ";
					Object[] objs = new Object[3];
					objs[0] = selectTlrno;
					objs[1] = sdf.format(new Date());
					objs[2] = id;
					num = num +rootdao.executeSqlWithPara(sql,objs);
				}else{
					String sql=" UPDATE CREDIT_CARD_ALERT SET OPERATOR_TLR = ? WHERE REC_ID = ? ";
					Object[] objs = new Object[2];
					objs[0] = selectTlrno;
					objs[1] = id;
					num = num +rootdao.executeSqlWithPara(sql,objs);
				}
			}
		}
		
		GlobalInfo globalInfo = GlobalInfo.getCurrentInstance();
		HsbcAmlBizLogUtils.setLogToBizLog(globalInfo,"Updater.log",new String[] { globalInfo.getTlrno(), globalInfo.getBrno(), "Case分派-确认分派，分派交易数量为【"+num+"】，分派给【"+selectTlrno+"】"}, "Case任务分派");
		
		return updateReturnBean;
	}

}
