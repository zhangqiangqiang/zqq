package com.huateng.hsbc.creditcard.update;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.huateng.commquery.result.MultiUpdateResultBean;
import com.huateng.commquery.result.UpdateResultBean;
import com.huateng.commquery.result.UpdateReturnBean;
import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.operation.orm.HQLDAO;
import com.huateng.ebank.framework.web.commQuery.BaseUpdate;
import com.huateng.exception.AppException;
import com.huateng.hsbc.creditcard.bean.CreditCardAlert;
import com.huateng.hsbc.creditcard.bean.CreditCardAuditTrail;
import com.huateng.hsbc.creditcard.bean.CreditCardMsg;
import com.huateng.hsbc.creditcard.utils.CreditCommUtils;
import com.huateng.hsbc.creditcard.utils.CreditConstant;

public class SaveMsgUpdate extends BaseUpdate{
	private static final String DATASET_ID_1="CreditCardMsgDtl";
	private static final String DATASET_ID_2="CreditCardDtl";
	
	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean paramMultiUpdateResultBean,
			HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
			throws AppException {
		GlobalInfo gi = GlobalInfo.getCurrentInstance();
		CreditCardMsg msg = new CreditCardMsg();
		CreditCardAlert alert = new CreditCardAlert();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		
		UpdateReturnBean updateReturnBean = new UpdateReturnBean();
		UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID(DATASET_ID_1);
		if (updateResultBean.hasNext()) {
			Map map = updateResultBean.next();
			mapToObject(msg, map);
		}
		
		updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID(DATASET_ID_2);
		if (updateResultBean.hasNext()) {
			Map map = updateResultBean.next();
			mapToObject(alert, map);
		}
		
		msg.setId(CreditCommUtils.getUUID());
		msg.setMainId(alert.getId());
		msg.setSaveTime(sdf.format(new Date()));
		msg.setStatus(CreditConstant.SendStatus.STATUS_0.getValue());
		msg.setAlarmNo(alert.getAlarmNo());
		msg.setAlarmDate(alert.getAlarmDate());
		
		StringBuffer hql = new StringBuffer("from CreditCardMsg where mainId = '");
		hql.append(alert.getId()).append("' order by saveTime desc");
		List<CreditCardMsg> msgs = rootdao.queryByQL2List(hql.toString());
		String oldValue = null;
		if(msgs!=null&&msgs.size()>0){
			CreditCardMsg obj = msgs.get(0);
			oldValue = obj.getMsgType();
		}
		
		//Audit
		CreditCardAuditTrail audit = new CreditCardAuditTrail();
		audit.setId(CreditCommUtils.getUUID());
		audit.setAlarmNo(msg.getAlarmNo());
		audit.setFieldName("短信内容");
		audit.setOldValue(CreditCommUtils.getDataDic(oldValue, "1004"));
		audit.setNewValue(CreditCommUtils.getDataDic(msg.getMsgType(), "1004"));
		audit.setOperatorTlr(gi.getTlrno());
		audit.setOperatorTime(sdf.format(new Date()));
		rootdao.save(audit);
		
		rootdao.saveOrUpdate(msg);
		
		return updateReturnBean;
	}

}
