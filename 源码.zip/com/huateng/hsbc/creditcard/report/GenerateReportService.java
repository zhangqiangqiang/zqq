package com.huateng.hsbc.creditcard.report;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.List;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.huateng.hsbc.creditcard.bean.CreditCardReportConf;
import com.huateng.hsbc.creditcard.utils.CreditCommUtils;
import com.huateng.hsbc.creditcard.utils.CreditConstant;

public class GenerateReportService {
	/**
	 * 生成为EXCEL文件    
	 */
	public static File createXLSFile(ResultSet exportData,File file, List<CreditCardReportConf> confs) throws Exception {
		OutputStream fileOut = null;
		InputStream is = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(is);
    	SXSSFWorkbook workbook = new SXSSFWorkbook(wb);//SXSSFWorkbook会自动清理缓存，解决内存溢出问题
    	XSSFCellStyle cellStyle;
		int sheetNum =2;
		Sheet sheet = workbook.getSheet("sheet1");
		int i = 1;
		Row row;
		//表头
		row = sheet.createRow(0);
		for(int z=0;z<confs.size();z++){
			CreditCardReportConf reportBean = confs.get(z);
			Cell cell = row.createCell(z);
			cell.setCellValue(reportBean.getFieldDesc());
			cellStyle = (XSSFCellStyle) workbook.createCellStyle();
			setBold(workbook,cellStyle);
			setBorder(cellStyle);
//			cellStyle.setWrapText(true);
			cell.setCellStyle(cellStyle);
		}
		
		while (exportData.next()) {
			row = sheet.createRow(i);
			for(int z=0;z<confs.size();z++){
				CreditCardReportConf reportBean = confs.get(z);
				Cell cell = row.createCell(z);
				cellStyle = (XSSFCellStyle) workbook.createCellStyle();
				if(CreditConstant.ReportFieldType.VARCHAR2.getValue().equals(reportBean.getFieldType())){
					cell.setCellValue(CreditCommUtils.isNull(exportData.getString(reportBean.getFieldName())));
				}else if(CreditConstant.ReportFieldType.NUMBER.getValue().equals(reportBean.getFieldType())){
					cell.setCellValue(CreditCommUtils.isNullIntger(exportData.getBigDecimal(reportBean.getFieldName())));
				}else if(CreditConstant.ReportFieldType.BIGDECIMAL.getValue().equals(reportBean.getFieldType())){
					String dic = reportBean.getFieldDic();
					int point = -1;
					if(dic!=null){
						point = Integer.parseInt(dic);
					}
					cell.setCellValue(CreditCommUtils.isNullBigDecimal(exportData.getBigDecimal(reportBean.getFieldName()),point));
				}else if(CreditConstant.ReportFieldType.DATADIC.getValue().equals(reportBean.getFieldType())){
					cell.setCellValue(CreditCommUtils.getDataDic(CreditCommUtils.isNull(exportData.getString(reportBean.getFieldName())),reportBean.getFieldDic()));
				}else if(CreditConstant.ReportFieldType.DATETIME.getValue().equals(reportBean.getFieldType())){
					cell.setCellValue(CreditCommUtils.isNullTime(exportData.getString(reportBean.getFieldName())));
				}
				setBorder(cellStyle);
				cellStyle.setWrapText(true);
				cell.setCellStyle(cellStyle);
			}
			i++;
			if (i % 500000 == 0) {// 超过50万切换sheet
				sheet = workbook.createSheet("sheet"+sheetNum);
				Row firstRow=sheet.createRow(0);//表头
				for(int z=0;z<confs.size();z++){
					CreditCardReportConf reportBean = confs.get(z);
		    		Cell cell = firstRow.createCell(z);
		    		cell.setCellValue(reportBean.getFieldDesc());
		    		cellStyle = (XSSFCellStyle) workbook.createCellStyle();
					setBold(workbook,cellStyle);
					setBorder(cellStyle);
//					cellStyle.setWrapText(true);
					cell.setCellStyle(cellStyle);
		    	}
				i = 1;
				sheetNum = sheetNum+1;
			}
		}
		for(int z=0;z<confs.size();z++){
			for(int q=1;q<sheetNum;q++){
				Sheet sheetS = workbook.getSheet("sheet"+q);
				sheetS.autoSizeColumn(z);
				int colWidth = sheet.getColumnWidth(z);
				if(colWidth<20*256) {
					sheetS.setColumnWidth(z, 20*256);
				}else if(colWidth>50*256) {
					sheetS.setColumnWidth(z, 50*256);
				}
			}
		}
		fileOut = new FileOutputStream(file);
		workbook.write(fileOut);
		if (fileOut != null) {
			fileOut.close();
		}
		workbook.dispose();
		return file;
	}
	
	/*
	 * 设置边框
	 */
	private static void setBorder(XSSFCellStyle cellStyle) {
		cellStyle.setBorderBottom(BorderStyle.THIN); //下边框
		cellStyle.setBorderLeft(BorderStyle.THIN);//左边框
		cellStyle.setBorderTop(BorderStyle.THIN);//上边框
		cellStyle.setBorderRight(BorderStyle.THIN);//右边框
	}
	/*
	 * 粗体
	 */
	private static void setBold(SXSSFWorkbook workbook,XSSFCellStyle cellStyle) {
		XSSFFont font = (XSSFFont) workbook.createFont();
		font.setBold(true);
		cellStyle.setFont(font);
	}
}
