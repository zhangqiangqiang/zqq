package com.huateng.hsbc.creditcard.report;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.hibernate3.SessionFactoryUtils;

import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.business.common.UserSessionInfo;
import com.huateng.ebank.framework.util.WebDownloadFile;
import com.huateng.ebank.framework.web.servlet.BaseServlet;
import com.huateng.excel.imp.DataMyUtil;
import com.huateng.exception.AppException;
import com.huateng.hsbc.creditcard.bean.CreditCardReportConf;
import com.huateng.report.aml.feedback.service.AmlFeedBackservice;
import com.huateng.report.constants.AMLConstants;

/**
 *  3号令 - 大额无规则交易导出
 */
public class CreditCardAction extends BaseServlet {
	private static final Log log = LogFactory.getLog(CreditCardAction.class);
	
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
    	ROOTDAO rootDao= ROOTDAOUtils.getROOTDAO();
    	File file = null;
    	Connection conn = null;
		java.sql.PreparedStatement st = null;
		java.sql.ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		String excelName = "";
		
        try {
            this.init(request);
            GlobalInfo gInfo = GlobalInfo.getCurrentInstance();
            String reportId = request.getParameter("reportId");
            if("AuditTrail".equals(reportId)){
            	excelName = "AUDIT_TRAIL";
            	String qalarmNo = request.getParameter("qalarmNo");
                String qoperatorTlr = request.getParameter("qoperatorTlr");
                String qDateStart = request.getParameter("qDateStart");
                String qDateEnd = request.getParameter("qDateEnd");
                
                sql.append("select * from CREDIT_CARD_AUDIT_TRAIL t where 1=1");
            	if (StringUtils.isNotBlank(qalarmNo)) {
                    sql.append(" AND t.ALARM_NO = '"+qalarmNo+"'");
                }
            	if (StringUtils.isNotBlank(qoperatorTlr)) {
                    sql.append(" AND t.OPERATOR_TLR = '"+qoperatorTlr+"'");
                }
            	if (StringUtils.isNotBlank(qDateStart)) {
                    sql.append(" AND t.OPERATOR_TIME >= '"+qDateStart+"000000'");
                }
            	if (StringUtils.isNotBlank(qDateEnd)) {
                    sql.append(" AND t.OPERATOR_TIME <= '"+qDateEnd+"235959'");
                }
            	sql.append(" order by t.ALARM_NO,t.OPERATOR_TIME ");
            	
            }else if("CaseManagement".equals(reportId)){
            	excelName = "CASE_MANAGEMENT";
            	String qalarmNo = request.getParameter("qalarmNo");
                String qoperatorTlr = request.getParameter("qoperatorTlr");
                String qalarmStartDate = request.getParameter("qalarmStartDate");
                String qalarmEndDate = request.getParameter("qalarmEndDate");
//            	sql.append("SELECT t.*,b.TLR_NAME from CREDIT_CARD_ALERT t,TLR_INFO b where t.OPERATOR_TLR=b.TLRNO");
//                sql.append("SELECT t.*,b.TLR_NAME from CREDIT_CARD_ALERT t LEFT JOIN TLR_INFO b ON t.OPERATOR_TLR=b.TLRNO where 1=1 ");
                sql.append("SELECT t.* from VI_CREDIT_CARD_CASE_MANAGEMENT t where 1=1 ");
            	if (StringUtils.isNotBlank(qalarmStartDate)) {
                    sql.append(" AND t.ALARM_DATE >= '"+qalarmStartDate+"'");
                }
            	if (StringUtils.isNotBlank(qalarmEndDate)) {
                    sql.append(" AND t.ALARM_DATE <= '"+qalarmEndDate+"'");
                }
            	if (StringUtils.isNotBlank(qalarmNo)) {
                    sql.append(" AND t.ALARM_NO = '"+qalarmNo+"'");
                }
            	if (StringUtils.isNotBlank(qoperatorTlr)) {
        			if("N/A".equalsIgnoreCase(qoperatorTlr)){
        				sql.append(" AND t.OPERATOR_TLR is null ");
        			}else{
        				sql.append(" AND t.OPERATOR_TLR = '"+qoperatorTlr+"'");
        			}
        		}
            	sql.append(" order by t.ALARM_DATE,t.ALARM_NO");
            }else if("OverView".equals(reportId)){
            	excelName = "SYSTEM_MANAGEMENT_OVERVIEW";
            	String qalarmDateStart = request.getParameter("qalarmDateStart");
            	String qalarmDateEnd = request.getParameter("qalarmDateEnd");
            	sql.append("select * from VI_CREDIT_CARD_OVERVIEW t where 1=1 ");
            	if (StringUtils.isNotBlank(qalarmDateStart)) {
                    sql.append(" AND t.ALARM_DATE >= '"+qalarmDateStart+"'");
                }
            	if (StringUtils.isNotBlank(qalarmDateEnd)) {
                    sql.append(" AND t.ALARM_DATE <= '"+qalarmDateEnd+"'");
                }
            	sql.append(" order by t.ALARM_DATE");
            }else if("PageSelect".equals(reportId)){//页面选择导出
            	excelName = "ALERT";
            	sql.append("select * from CREDIT_CARD_ALERT t where ");
            	String ids = request.getParameter("ids");
            	String[] idArr = ids.split(",");
            	for(int i=0;i<idArr.length;i++){
            		if(i==0){
            			sql.append(" REC_ID = '"+idArr[i]+"'");
            		}else{
            			sql.append(" OR REC_ID = '"+idArr[i]+"'");
            		}
            	}
            	sql.append(" order by ALARM_DATE desc,ALARM_NO");
            }else if("Staff".equalsIgnoreCase(reportId)){
            	//System Management Operator
            	excelName = "SYSTEM_MANAGEMENT_STAFF";
            	String qDateStart = request.getParameter("qDateStart");
            	String qDateEnd = request.getParameter("qDateEnd");
            	sql.append("select * from VI_CREDIT_CARD_STAFF t where 1=1 ");
            	if (StringUtils.isNotBlank(qDateStart)) {
                    sql.append(" AND t.SHOW_DATE >= '"+qDateStart+"'");
                }
            	if (StringUtils.isNotBlank(qDateEnd)) {
                    sql.append(" AND t.SHOW_DATE <= '"+qDateEnd+"'");
                }
            	sql.append(" order by t.SHOW_DATE");
            }else if("CreditTransactionDetail".equalsIgnoreCase(reportId)){
            	//Transaction Detail report
            	excelName = "CREDIT_TRANSACTION_DETAIL";
            	String qDateStart = request.getParameter("qDateStart");
            	String qDateEnd = request.getParameter("qDateEnd");
            	sql.append("select * from CREDIT_TRANSACTION_DETAIL t where 1=1 ");
            	if (StringUtils.isNotBlank(qDateStart)) {
                    sql.append(" AND t.BATCH_NO >= '"+qDateStart+"'");
                }
            	if (StringUtils.isNotBlank(qDateEnd)) {
                    sql.append(" AND t.BATCH_NO <= '"+qDateEnd+"'");
                }
            	sql.append(" order by t.BATCH_NO,t.ALERT_ID,t.TRANSACTION_DATE,t.TRANSACTION_TIME");
            }else if("AttentionListGeneral".equalsIgnoreCase(reportId)){
            	//信用卡告警自动短信报表
            	excelName = "ATTENTION_LIST_GENERAL";
            	String qDateStart = request.getParameter("qDateStart");
            	String qDateEnd = request.getParameter("qDateEnd");
            	sql.append("select * from ATTENTION_LIST_GENERAL t where 1=1 ");
            	if (StringUtils.isNotBlank(qDateStart)) {
                    sql.append(" AND t.ALARM_DATE >= '"+qDateStart+"'");
                }
            	if (StringUtils.isNotBlank(qDateEnd)) {
                    sql.append(" AND t.ALARM_DATE <= '"+qDateEnd+"'");
                }
            	sql.append(" order by t.ALARM_DATE");
            }else if("SendAgentSystem".equalsIgnoreCase(reportId)){
            	//信用卡告警发送坐席系统报表
            	excelName = "SEND_AGENT_SYSTEM";
            	String qDateStart = request.getParameter("qDateStart");
            	String qDateEnd = request.getParameter("qDateEnd");
            	sql.append("select * from SEND_AGENT_SYSTEM t where 1=1 ");
            	if (StringUtils.isNotBlank(qDateStart)) {
                    sql.append(" AND t.REPORT_DATE >= '"+qDateStart+"'");
                }
            	if (StringUtils.isNotBlank(qDateEnd)) {
                    sql.append(" AND t.REPORT_DATE <= '"+qDateEnd+"'");
                }
            	sql.append(" order by t.ALARM_DATE");
            }else if("CreditStaffAlert".equalsIgnoreCase(reportId)){
            	//信用卡告警员工相关报表
            	excelName = "CREDIT_STAFF_ALERT";
            	String qlstDate = request.getParameter("qlstDate");
            	sql.append("select * from CREDIT_STAFF_ALERT t where 1=1 ");
            	if (StringUtils.isNotBlank(qlstDate)) {
                    sql.append(" AND t.CLOSE_ALERT_TIME = '"+qlstDate+"'");
                }
            	sql.append(" order by t.ALARM_DATE");
            }
            log.info(sql.toString());
            
            //列信息
            List<CreditCardReportConf> confs = rootDao.queryByQL2List("from CreditCardReportConf where reportId='"+reportId+"' order by fieldIndex");
            
            InputStream inputStream =  this.getClass().getClassLoader().getResourceAsStream("com/huateng/hsbc/creditcard/report/templet.xlsx");
        	AmlFeedBackservice service = AmlFeedBackservice.getInstance();
      		String path = service.getParentDir("Downoload", "AML");
  			String currentTime = DataMyUtil.getFullDateTime();
  			String destFileName = path + "filetmp/" + excelName + "-" + currentTime + ".xlsx";
  			file = new File(destFileName);
  			CopyFile.copyFile(inputStream, file, true);
  			
  			
  			conn = SessionFactoryUtils.getDataSource(ROOTDAOUtils.getROOTDAO().getSessionFactory()).getConnection();
  			st = conn.prepareStatement(sql.toString());
  			rs = st.executeQuery();
  			GenerateReportService generateReportService = new GenerateReportService();
  			generateReportService.createXLSFile(rs,file,confs);
  			WebDownloadFile.downloadFile(resp, file, file.getName());
  			
			ServletContext serContext = this.getServletContext();
			UserSessionInfo userInfo = (UserSessionInfo) this.getSession(request).getAttribute("USER_SESSION_INFO");
			String tlrno = userInfo.getTlrNo();
			serContext.setAttribute(AMLConstants.REPORT_APP_TYPE_AML + "_"+ tlrno, AMLConstants.REPORT_APP_TYPE_AML);
        } catch(AppException ae){
            ae.printStackTrace();
            String errMsg = ae.toString();
            request.setAttribute("errormsg", errMsg);
            request.getRequestDispatcher("/common/error.jsp").forward(request, resp);
            resp.sendRedirect(request.getContextPath() + "/common/error.jsp");
        }catch (Exception e) {
        	e.printStackTrace();
            String errMsg = e.toString();
            request.setAttribute("errormsg", errMsg);
            request.getRequestDispatcher("/common/error.jsp").forward(request, resp);
            resp.sendRedirect(request.getContextPath() + "/common/error.jsp");
        }finally {
			if (file.exists()) {
				file.delete();
			}
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(st!=null){
				try {
					st.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
    }
}