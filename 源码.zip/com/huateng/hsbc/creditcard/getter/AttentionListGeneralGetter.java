package com.huateng.hsbc.creditcard.getter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringEscapeUtils;

import com.huateng.common.err.Module;
import com.huateng.common.err.Rescode;
import com.huateng.commquery.result.Result;
import com.huateng.commquery.result.ResultMng;
import com.huateng.ebank.business.common.PageQueryCondition;
import com.huateng.ebank.business.common.PageQueryResult;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.exceptions.CommonException;
import com.huateng.ebank.framework.util.DataFormat;
import com.huateng.ebank.framework.web.commQuery.BaseGetter;
import com.huateng.exception.AppException;
import com.huateng.hsbc.creditcard.utils.CreditCommUtils;
import com.huateng.hsbc.creditcard.utils.CreditConstant;
import com.huateng.report.common.service.ReportCommonService;


/**
 * @author qq.zhang
 */
@SuppressWarnings("unchecked")
public class AttentionListGeneralGetter extends BaseGetter {
	
	public Result call() throws AppException {
		try {
			PageQueryResult pageResult = getData();
			ResultMng.fillResultByList(getCommonQueryBean(),
					getCommQueryServletRequest(), pageResult.getQueryResult(),
					getResult());
			result.setContent(pageResult.getQueryResult());
			result.getPage().setTotalPage(
					pageResult.getPageCount(getResult().getPage()
							.getEveryPage()));
			result.init();
			result.setTotal(pageResult.getTotalCount());
			return result;
		} catch (AppException appEx) {
			throw appEx;
		} catch (Exception ex) {
			throw new AppException(Module.SYSTEM_MODULE,Rescode.DEFAULT_RESCODE, ex.getMessage(), ex);
		}
	}

	private PageQueryResult getData() throws CommonException {

		int pageSize = getResult().getPage().getEveryPage();
		int pageIndex = getResult().getPage().getCurrentPage();
//		GlobalInfo gInfo = GlobalInfo.getCurrentInstance();
		ROOTDAO rootDAO = ROOTDAOUtils.getROOTDAO();
		PageQueryResult pageQueryResult = null;
		PageQueryCondition queryCondition = new PageQueryCondition();
		List<Object> paramentList = new ArrayList<Object>();
		
		StringBuilder hql = new StringBuilder(" SELECT model FROM AttentionListGeneral model WHERE 1=1 ");
		
		Map<String, String> map = getCommQueryServletRequest().getParameterMap();   
		String qDateStart     = map.get("qDateStart");               
		String qDateEnd       = map.get("qDateEnd");      
		
		if (!DataFormat.isEmpty(qDateStart)) {
			hql.append(" AND model.alarm_date >= ? ");
			paramentList.add(qDateStart);
		}
		if (!DataFormat.isEmpty(qDateEnd)) {
			hql.append(" AND model.alarm_date <= ? ");
			paramentList.add(qDateEnd);
		}
		hql.append(" order by model.alarm_date");
		
		queryCondition.setQueryString(hql.toString());
		queryCondition.setPageIndex(pageIndex);
		queryCondition.setPageSize(pageSize);
		queryCondition.setObjArray(paramentList.toArray());
		pageQueryResult = rootDAO.pageQueryByQL(queryCondition);
	    return pageQueryResult;
	}
}