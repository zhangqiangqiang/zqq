package com.huateng.hsbc.creditcard.getter;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;

import com.huateng.commquery.result.Result;
import com.huateng.commquery.result.ResultMng;
import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.business.common.PageQueryCondition;
import com.huateng.ebank.business.common.PageQueryResult;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.entity.data.mng.TlrInfo;
import com.huateng.ebank.framework.exceptions.CommonException;
import com.huateng.ebank.framework.web.commQuery.BaseGetter;
import com.huateng.exception.AppException;
import com.huateng.report.hf.aml.utils.HsbcAmlUtils;

public class CreditCardtlrNoSelectGetter extends BaseGetter {
	/*
	 * 参数段编号下拉框(模糊筛选框)
	 * 
	 */
	@Override
	public Result call() throws AppException {
		// TODO Auto-generated method stub
		String value = StringEscapeUtils.escapeHtml(this.getCommQueryServletRequest().getParameter("value"));//this.getCommQueryServletRequest().getParameter("value");
		int pageSize = this.getResult().getPage().getEveryPage();
		int pageIndex = this.getResult().getPage().getCurrentPage();
		PageQueryResult pageResult = paramgroupIdSelect(pageIndex, pageSize, value);
		ResultMng.fillResultByList(getCommonQueryBean(), getCommQueryServletRequest(), pageResult.getQueryResult(),
				getResult());
		result.setContent(pageResult.getQueryResult());
		result.getPage().setTotalPage(pageResult.getPageCount(getResult().getPage().getEveryPage()));
		result.init();
		result.setTotal(pageResult.getTotalCount());
		return result;
	}
	
	public PageQueryResult paramgroupIdSelect(int pageIndex, int pageSize, String value) throws CommonException {
//		GlobalInfo gInfo = GlobalInfo.getCurrentInstance();
//		String tlrnosql = "select a.tlr_no from tlr_bctl_rel a where a.br_no='" +gInfo.getBrno()+"' "+
//						 " INTERSECT "+
//				         " select b.tlrno from TLR_ROLE_REL b,role_info c where b.role_id=c.role_id and REGEXP_LIKE(c.role_name,'("+HsbcAmlUtils.getDepartByUserId(gInfo.getTlrno())+"#PACKAGE|"+HsbcAmlUtils.getDepartByUserId(gInfo.getTlrno())+"#MAKER)')";
//		Iterator tlrnoList = ROOTDAOUtils.getROOTDAO().queryBySQL(tlrnosql.toString());
//		String tlrnos = "";
//		while(tlrnoList.hasNext()){
//			String tlrno = (String)tlrnoList.next();
//			tlrnos += "'"+tlrno+"',";  //获取同一机构同一部门下的所有用户
//		}
//		tlrnos = tlrnos.substring(0, tlrnos.length()-1);   //截取掉最后一位逗号
//		String hql = "from TlrInfo t  where t.tlrno in ("+tlrnos+") ";
//		if (StringUtils.isNotBlank(value)){
//			hql += " and t.tlrno like '%" + value + "%'";
//		}
		PageQueryCondition queryCondition = new PageQueryCondition();
		Object[] objArray = new Object[1];
		String hql = "from TlrInfo t  where 1 = 1 ";
		if (StringUtils.isNotBlank(value)&&!"%%".equals(value)){
			hql += " and t.tlrno like ?";
			objArray[0] = ("%" + value + "%");
			queryCondition.setObjArray(objArray);
//			hql += " and t.tlrno like '%" + value + "%'";
		}
		
		ROOTDAO rootDAO = ROOTDAOUtils.getROOTDAO();
		queryCondition.setPageIndex(pageIndex);
		queryCondition.setPageSize(pageSize);
		queryCondition.setQueryString(hql);
		List<TlrInfo> list = new ArrayList<TlrInfo>();
		
		PageQueryResult pageQueryResult = null;
		try{
			pageQueryResult = rootDAO.pageQueryByQL((queryCondition));
			Iterator it = pageQueryResult.getQueryResult().iterator() ;
			while(it.hasNext()) {
				Object[] queryArray = (Object[]) it.next();
				TlrInfo t = (TlrInfo) queryArray[0];
				list.add(t);
			}
			pageQueryResult.setQueryResult(list);
		} catch (CommonException e) {
			e.printStackTrace();
		}
		return pageQueryResult;
	}
}
