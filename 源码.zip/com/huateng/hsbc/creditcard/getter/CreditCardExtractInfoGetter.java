package com.huateng.hsbc.creditcard.getter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringEscapeUtils;

import com.huateng.common.err.Module;
import com.huateng.common.err.Rescode;
import com.huateng.commquery.result.Result;
import com.huateng.commquery.result.ResultMng;
import com.huateng.ebank.business.common.PageQueryCondition;
import com.huateng.ebank.business.common.PageQueryResult;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.exceptions.CommonException;
import com.huateng.ebank.framework.util.DataFormat;
import com.huateng.ebank.framework.web.commQuery.BaseGetter;
import com.huateng.exception.AppException;
import com.huateng.hsbc.creditcard.utils.CreditCommUtils;
import com.huateng.hsbc.creditcard.utils.CreditConstant;


/**
 * @author qq.zhang 自查提交
 */
@SuppressWarnings("unchecked")
public class CreditCardExtractInfoGetter extends BaseGetter {
	
	public Result call() throws AppException {
		try {
			PageQueryResult pageResult = getData();
			ResultMng.fillResultByList(getCommonQueryBean(),
					getCommQueryServletRequest(), pageResult.getQueryResult(),
					getResult());
			result.setContent(pageResult.getQueryResult());
			result.getPage().setTotalPage(
					pageResult.getPageCount(getResult().getPage()
							.getEveryPage()));
			result.init();
			result.setTotal(pageResult.getTotalCount());
			return result;
		} catch (AppException appEx) {
			throw appEx;
		} catch (Exception ex) {
			throw new AppException(Module.SYSTEM_MODULE,Rescode.DEFAULT_RESCODE, ex.getMessage(), ex);
		}
	}

	private PageQueryResult getData() throws CommonException {

		int pageSize = getResult().getPage().getEveryPage();
		int pageIndex = getResult().getPage().getCurrentPage();
//		GlobalInfo gInfo = GlobalInfo.getCurrentInstance();
		ROOTDAO rootDAO = ROOTDAOUtils.getROOTDAO();
		PageQueryResult pageQueryResult = null;
		PageQueryCondition queryCondition = new PageQueryCondition();
		List<Object> paramentList = new ArrayList<Object>();
		StringBuilder hql = new StringBuilder(" SELECT model FROM CreditCardAlert model WHERE recStatus = ? ");
		paramentList.add(CreditConstant.RecStatus.STATUS_02.getValue());
		Map<String, String> map = getCommQueryServletRequest().getParameterMap();
		hql.append(" AND approveTlr is null ");
		
		//5个工作日内可查询
		String limit = CreditCommUtils.getLimitWorkDate(rootDAO);
		hql.append(" AND model.closeAlerttime <? ");
		paramentList.add(limit+"000000");
		
		String qalarmDateStart    = map.get("qalarmDateStart");
		String qalarmDateEnd      = map.get("qalarmDateEnd");
		String qcustName          = map.get("qcustName");         
		String qcustCertno        = map.get("qcustCertno");       
		String qcustPhoneno       = map.get("qcustPhoneno");      
		String qcreditCardcny     = map.get("qcreditCardcny");    
		String qalarmNo           = map.get("qalarmNo");          
		String qproofResult       = map.get("qproofResult");      
		String qmerchantResult    = map.get("qmerchantResult");   
		String qoutboundResult    = map.get("qoutboundResult");   
		String qinvestigateResult = map.get("qinvestigateResult");
		String qmessageResult     = map.get("qmessageResult");    
		String qbillStage         = map.get("qbillStage");        
		String qreduce            = map.get("qreduce");           
		String qcardFreeze        = map.get("qcardFreeze");       
		String qoperatorTlr       = map.get("qoperatorTlr"); 
		String qriskLevel        = map.get("qriskLevel");
		String qcustNo       = map.get("qcustNo");
		
		if (!DataFormat.isEmpty(qcustNo)) {
			hql.append(" AND model.custNo = ? ");
			paramentList.add(qcustNo);
		}
		if (!DataFormat.isEmpty(qriskLevel)) {
			hql.append(" AND model.riskLevel = ? ");
			paramentList.add(qriskLevel);
		}
		if (!DataFormat.isEmpty(qalarmDateStart)) {
			hql.append(" AND model.alarmDate >= ? ");
			paramentList.add(qalarmDateStart);
		}
		if (!DataFormat.isEmpty(qalarmDateEnd)) {
			hql.append(" AND model.alarmDate <= ? ");
			paramentList.add(qalarmDateEnd);
		}
		if (!DataFormat.isEmpty(qcustName)) {
			hql.append(" AND model.custName like ? ");
			paramentList.add("%"+qcustName+"%");
		}
		if (!DataFormat.isEmpty(qcustCertno)) {
			hql.append(" AND model.custCertno = ? ");
			paramentList.add(qcustCertno);
		}
		if (!DataFormat.isEmpty(qcustPhoneno)) {
			hql.append(" AND model.custPhoneno = ? ");
			paramentList.add(qcustPhoneno);
		}
		if (!DataFormat.isEmpty(qcreditCardcny)) {
			hql.append(" AND model.creditCardcny = ? ");
			paramentList.add(qcreditCardcny);
		}
		if (!DataFormat.isEmpty(qalarmNo)) {
			hql.append(" AND model.alarmNo = ? ");
			paramentList.add(qalarmNo);
		}
		if (!DataFormat.isEmpty(qproofResult)) {
			hql.append(" AND model.proofResult = ? ");
			paramentList.add(qproofResult);
		}
		if (!DataFormat.isEmpty(qmerchantResult)) {
			hql.append(" AND model.merchantResult = ? ");
			paramentList.add(qmerchantResult);
		}
		if (!DataFormat.isEmpty(qoutboundResult)) {
			hql.append(" AND model.outboundResult = ? ");
			paramentList.add(qoutboundResult);
		}
		if (!DataFormat.isEmpty(qinvestigateResult)) {
			hql.append(" AND model.investigateResult = ? ");
			paramentList.add(qinvestigateResult);
		}
		if (!DataFormat.isEmpty(qmessageResult)) {
			hql.append(" AND model.messageResult = ? ");
			paramentList.add(qmessageResult);
		}
		if (!DataFormat.isEmpty(qbillStage)) {
			hql.append(" AND model.billStage = ? ");
			paramentList.add(qbillStage);
		}
		if (!DataFormat.isEmpty(qreduce)) {
			hql.append(" AND model.reduce = ? ");
			paramentList.add(qreduce);
		}
		if (!DataFormat.isEmpty(qcardFreeze)) {
			hql.append(" AND model.cardFreeze = ? ");
			paramentList.add(qcardFreeze);
		}
		if (!DataFormat.isEmpty(qoperatorTlr)) {
			hql.append(" AND model.operatorTlr = ? ");
			paramentList.add(qoperatorTlr);
		}
		hql.append(" order by alarmDate desc,alarmNo");
		//修改仅属于操作员的能看到
//		hql.append(" AND model.operatorTlr = ? ");
//		paramentList.add(gInfo.getTlrno());
		
		queryCondition.setQueryString(hql.toString());
		queryCondition.setPageIndex(pageIndex);
		queryCondition.setPageSize(pageSize);
		queryCondition.setObjArray(paramentList.toArray());
		pageQueryResult = rootDAO.pageQueryByQL(queryCondition);
	    return pageQueryResult;
	}
}