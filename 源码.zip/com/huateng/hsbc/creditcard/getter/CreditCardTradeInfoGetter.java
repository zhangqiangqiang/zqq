package com.huateng.hsbc.creditcard.getter;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringEscapeUtils;

import com.huateng.common.err.Module;
import com.huateng.common.err.Rescode;
import com.huateng.commquery.result.Result;
import com.huateng.commquery.result.ResultMng;
import com.huateng.ebank.business.common.PageQueryCondition;
import com.huateng.ebank.business.common.PageQueryResult;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.exceptions.CommonException;
import com.huateng.ebank.framework.util.DataFormat;
import com.huateng.ebank.framework.web.commQuery.BaseGetter;
import com.huateng.exception.AppException;
import com.huateng.hsbc.creditcard.bean.CreditCardAlert;
import com.huateng.hsbc.creditcard.bean.CreditCardTrade;
import com.huateng.hsbc.creditcard.utils.CreditConstant;

import edu.emory.mathcs.backport.java.util.Collections;


/**
 * @author qq.zhang 申领
 */
@SuppressWarnings("unchecked")
public class CreditCardTradeInfoGetter extends BaseGetter {
	
	public Result call() throws AppException {
		try {
			PageQueryResult pageResult = getData();
			ResultMng.fillResultByList(getCommonQueryBean(),
					getCommQueryServletRequest(), pageResult.getQueryResult(),
					getResult());
			result.setContent(pageResult.getQueryResult());
			result.getPage().setTotalPage(
					pageResult.getPageCount(getResult().getPage()
							.getEveryPage()));
			result.init();
			result.setTotal(pageResult.getTotalCount());
			return result;
		} catch (AppException appEx) {
			throw appEx;
		} catch (Exception ex) {
			throw new AppException(Module.SYSTEM_MODULE,Rescode.DEFAULT_RESCODE, ex.getMessage(), ex);
		}
	}

	private PageQueryResult getData() throws CommonException {

		int pageSize = getResult().getPage().getEveryPage();
		int pageIndex = getResult().getPage().getCurrentPage();
//		GlobalInfo gInfo = GlobalInfo.getCurrentInstance();
		ROOTDAO rootDAO = ROOTDAOUtils.getROOTDAO();
		PageQueryResult pageQueryResult = null;
		PageQueryCondition queryCondition = new PageQueryCondition();
		List<Object> paramentList = new ArrayList<Object>();
		StringBuilder hql = new StringBuilder("FROM CreditCardTrade WHERE 1 = 1 ");
		
		Map<String, String> map = getCommQueryServletRequest().getParameterMap();
		String id = map.get("id");
		CreditCardAlert alert = rootDAO.query(CreditCardAlert.class, id);
		hql.append(" AND alarmNo = ? ");
		paramentList.add(alert.getAlarmNo());
		
		hql.append(" order by tradeAmt desc , tradeDate desc , tradeTime desc");
		
		queryCondition.setQueryString(hql.toString());
		queryCondition.setPageIndex(pageIndex);
		queryCondition.setPageSize(pageSize);
		queryCondition.setObjArray(paramentList.toArray());
		pageQueryResult = rootDAO.pageQueryByQL(queryCondition);
		
		List<CreditCardTrade> sorts = new ArrayList<CreditCardTrade>();
		List<Object[]> list = pageQueryResult.getQueryResult();
		for (int i = 0; i < list.size(); i++) {
			Object[] result = (Object[]) list.get(i);
			CreditCardTrade trade = (CreditCardTrade) result[0];
			sorts.add(trade);
		}
		
		Collections.sort(sorts,new Comparator<CreditCardTrade>(){

			@Override
			public int compare(CreditCardTrade o1, CreditCardTrade o2) {
				// TODO Auto-generated method stub
//				if(!CreditConstant.DR.equals(o2.getRsv1())){
				if(CreditConstant.CR.equals(o2.getRsv1())){
					return -1;
				}
				return o2.getTradeAmt().compareTo(o1.getTradeAmt());
			}
			
		});
		
		for (int i = 0; i < list.size(); i++) {
			Object[] result = (Object[]) list.get(i);
			CreditCardTrade trade = (CreditCardTrade) result[0];
			for(int j=0;j<3&&j<sorts.size();j++){
				CreditCardTrade sort = sorts.get(j);
				if(trade.getId().equals(sort.getId())){
					trade.setSelectBackGround(true);
				}
			}
		}
		
	    return pageQueryResult;
	}
}