package com.huateng.hsbc.creditcard.operation;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.exceptions.CommonException;
import com.huateng.ebank.framework.operation.BaseOperation;
import com.huateng.ebank.framework.operation.OperationContext;
import com.huateng.ebank.framework.util.DataFormat;
import com.huateng.hsbc.creditcard.bean.CreditCardAlert;
import com.huateng.hsbc.creditcard.bean.CreditCardAuditTrail;
import com.huateng.hsbc.creditcard.utils.CreditCommUtils;
import com.huateng.hsbc.creditcard.utils.CreditConstant;
import com.huateng.report.hfaml3.utils.HfAml3Utils;

public class ModOperation  extends BaseOperation{
	public static final String ID = "ModOperation";
	public static final String MOD_BEAN = "MOD_BEAN";
	public static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
	
	@Override
	public void beforeProc(OperationContext context) throws CommonException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void execute(OperationContext context) throws CommonException {
		CreditCardAlert alert = (CreditCardAlert) context.getAttribute(MOD_BEAN);
		ROOTDAO rootDao= ROOTDAOUtils.getROOTDAO();
		GlobalInfo globalInfo = GlobalInfo.getCurrentInstance();
		CreditCardAlert alert_old = rootDao.query(CreditCardAlert.class, alert.getId());
		Map<String, List<Object>> changeMap = CreditCommUtils.compareFields(alert_old,alert,CreditCardAlert.compareArr);
		alert_old.setProofResult(alert.getProofResult());
		alert_old.setMerchantResult(alert.getMerchantResult());
		alert_old.setOutboundResult(alert.getOutboundResult());
		alert_old.setInvestigateResult(alert.getInvestigateResult());
		alert_old.setInvestigateReport(alert.getInvestigateReport());
		alert_old.setFcUar(alert.getFcUar());
		alert_old.setMessageResult(alert.getMessageResult());
		alert_old.setBillStage(alert.getBillStage());
		alert_old.setReduce(alert.getReduce());
		alert_old.setCardFreeze(alert.getCardFreeze());
		if (!DataFormat.isEmpty(alert.getInvestigateResult())
				&&!CreditConstant.INVESTIGATE_RESULT_01.equals(alert.getInvestigateResult())) {//不为空且不是调查中
			if(DataFormat.isEmpty(alert_old.getCheckFlag())||CreditConstant.Flag.Flag_0.getValue().equals(alert_old.getCheckFlag())){
				if(DataFormat.isEmpty(alert.getCloseAlerttime())){//只记录第一次
					alert_old.setCloseAlerttime(sdf.format(new Date()));
				}
			}else if(CreditConstant.Flag.Flag_1.getValue().equals(alert_old.getCheckFlag())){
				if(DataFormat.isEmpty(alert.getReClosealertTime())){//只记录第一次
					alert_old.setReClosealertTime(sdf.format(new Date()));
				}
			}
			alert_old.setRecStatus(CreditConstant.RecStatus.STATUS_02.getValue());
		}
		rootDao.update(alert_old);
		for(Map.Entry<String, List<Object>> entry : changeMap.entrySet()){
			String key = entry.getKey();
			List<Object> value = entry.getValue();
			CreditCardAuditTrail audit = new CreditCardAuditTrail();
			audit.setId(CreditCommUtils.getUUID());
			audit.setAlarmNo(alert_old.getAlarmNo());
			audit.setFieldName(CreditCardAlert.showMap.get(key));
			audit.setOldValue(HfAml3Utils.getDataDic((String)value.get(0),CreditCardAlert.dataDicMap.get(key)));
			audit.setNewValue(HfAml3Utils.getDataDic((String)value.get(1),CreditCardAlert.dataDicMap.get(key)));
			audit.setOperatorTlr(globalInfo.getTlrno());
			audit.setOperatorTime(sdf.format(new Date()));
			rootDao.save(audit);
		}
	}

	@Override
	public void afterProc(OperationContext context) throws CommonException {
		// TODO Auto-generated method stub
		
	}

}
