package com.huateng.hsbc.creditcard.operation;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.exceptions.CommonException;
import com.huateng.ebank.framework.operation.BaseOperation;
import com.huateng.ebank.framework.operation.OperationContext;
import com.huateng.ebank.framework.util.ExceptionUtil;
import com.huateng.hsbc.creditcard.bean.CreditCardAlert;
import com.huateng.hsbc.creditcard.utils.CreditCommUtils;
import com.huateng.hsbc.creditcard.utils.CreditConstant;

public class ExtractOperation  extends BaseOperation{
	public static final String ID = "ExtractOperation";
	public static final String IDS = "IDS";
	public static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
	
	@Override
	public void beforeProc(OperationContext context) throws CommonException {
		String ids = (String) context.getAttribute(IDS);
		String[] idArr = ids.split(",");
		ROOTDAO rootDao= ROOTDAOUtils.getROOTDAO();
		for(String id : idArr){
			CreditCardAlert alert = rootDao.query(CreditCardAlert.class, id);
//			if(CreditConstant.Flag.Flag_1.getValue().equals(alert.getCheckFlag())){
//				ExceptionUtil.throwCommonException2("存在已经被自查的记录");
//			}
			if(CreditCommUtils.isNotEmpty(alert.getApproveTlr())){
				ExceptionUtil.throwCommonException2("存在已经被申领的记录");
			}
		}
	}

	@Override
	public void execute(OperationContext context) throws CommonException {
		String ids = (String) context.getAttribute(IDS);
		String[] idArr = ids.split(",");
		GlobalInfo gi = GlobalInfo.getCurrentInstance();
		ROOTDAO rootDao= ROOTDAOUtils.getROOTDAO();
		for(String id : idArr){
			CreditCardAlert alert = rootDao.query(CreditCardAlert.class, id);			
			alert.setRecStatus(CreditConstant.RecStatus.STATUS_04.getValue());
			alert.setCheckFlag(CreditConstant.Flag.Flag_1.getValue());//modify 20200803
			alert.setApproveTlr(gi.getTlrno());
			rootDao.update(alert);
		}
	}

	@Override
	public void afterProc(OperationContext context) throws CommonException {
		// TODO Auto-generated method stub
		
	}

}
