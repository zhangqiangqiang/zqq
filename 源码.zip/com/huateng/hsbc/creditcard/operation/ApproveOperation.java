package com.huateng.hsbc.creditcard.operation;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.exceptions.CommonException;
import com.huateng.ebank.framework.operation.BaseOperation;
import com.huateng.ebank.framework.operation.OperationContext;
import com.huateng.ebank.framework.util.ExceptionUtil;
import com.huateng.hsbc.creditcard.bean.CreditCardAlert;
import com.huateng.hsbc.creditcard.bean.CreditCardAuditTrail;
import com.huateng.hsbc.creditcard.utils.CreditCommUtils;
import com.huateng.hsbc.creditcard.utils.CreditConstant;
import com.huateng.report.hfaml3.utils.HfAml3Utils;

public class ApproveOperation  extends BaseOperation{
	public static final String ID = "ApproveOperation";
	public static final String IDS = "IDS";
	public static final String APPROVE_STATUS = "APPROVE_STATUS";
	public static final String APPROVE_MEMO = "APPROVE_MEMO";
	
	public static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
	
	@Override
	public void beforeProc(OperationContext context) throws CommonException {
		GlobalInfo gi = GlobalInfo.getCurrentInstance();
		String ids = (String) context.getAttribute(IDS);
		String[] idArr = ids.split(",");
		ROOTDAO rootDao= ROOTDAOUtils.getROOTDAO();
		for(String id : idArr){
			CreditCardAlert alert = rootDao.query(CreditCardAlert.class, id);
//			if(!CreditConstant.RecStatus.STATUS_04.getValue().equals(alert.getRecStatus())){
//				ExceptionUtil.throwCommonException2("改记录已被审核！");
//			}
			String approveTlr = alert.getApproveTlr();
			if(!gi.getTlrno().equals(approveTlr)){
				ExceptionUtil.throwCommonException2("存在已经被其他人申领的记录！");
			}
		}
		
	}

	@Override
	public void execute(OperationContext context) throws CommonException {
		String ids = (String) context.getAttribute(IDS);
		String approveStatusChoose = (String) context.getAttribute(APPROVE_STATUS);
		String approveMemoChoose = (String) context.getAttribute(APPROVE_MEMO);
		String[] idArr = ids.split(",");
		GlobalInfo gi = GlobalInfo.getCurrentInstance();
		ROOTDAO rootDao= ROOTDAOUtils.getROOTDAO();
		
		if(CreditConstant.ApproveStatus.STATUS_01.getValue().equals(approveStatusChoose)){//01-Critical Error
			for(String id : idArr){
				CreditCardAlert alert = rootDao.query(CreditCardAlert.class, id);
				String approveStatusChoose_old = alert.getApproveStatus();
				String approveMemoChoose_old = alert.getApproveMemo();
				
				alert.setRecStatus(CreditConstant.RecStatus.STATUS_01.getValue());
				alert.setApproveStatus(approveStatusChoose);
				alert.setApproveMemo(approveMemoChoose);
				alert.setApproveTlr(gi.getTlrno());
				if(!CreditConstant.Flag.Flag_1.getValue().equals(alert.getCheckFlag())){
					alert.setReOpenalertTime(sdf.format(new Date()));
//					alert.setCheckFlag(CreditConstant.Flag.Flag_1.getValue());
				}
				rootDao.update(alert);
				
				//Audit
				//审核结果
				CreditCardAuditTrail audit = new CreditCardAuditTrail();
				audit.setId(CreditCommUtils.getUUID());
				audit.setAlarmNo(alert.getAlarmNo());
				audit.setFieldName("审核结果");
				audit.setOldValue(CreditConstant.ApproveStatus.getShow(approveStatusChoose_old));
				audit.setNewValue(CreditConstant.ApproveStatus.getShow(approveStatusChoose));
				audit.setOperatorTlr(gi.getTlrno());
				audit.setOperatorTime(sdf.format(new Date()));
				rootDao.save(audit);
				
				//审核说明
				if(!CreditCommUtils.strEqual(approveMemoChoose_old,approveMemoChoose)){
					CreditCardAuditTrail audit2 = new CreditCardAuditTrail();
					audit2.setId(CreditCommUtils.getUUID());
					audit2.setAlarmNo(alert.getAlarmNo());
					audit2.setFieldName("审核说明");
					audit2.setOldValue(approveMemoChoose_old);
					audit2.setNewValue(approveMemoChoose);
					audit2.setOperatorTlr(gi.getTlrno());
					audit2.setOperatorTime(sdf.format(new Date()));
					rootDao.save(audit2);
				}
			}
		}else{
			for(String id : idArr){
				CreditCardAlert alert = rootDao.query(CreditCardAlert.class, id);
				String approveStatusChoose_old = alert.getApproveStatus();
				String approveMemoChoose_old = alert.getApproveMemo();
				
				alert.setRecStatus(CreditConstant.RecStatus.STATUS_02.getValue());
				alert.setApproveStatus(approveStatusChoose);
				alert.setApproveMemo(approveMemoChoose);
				alert.setApproveTlr(gi.getTlrno());
				rootDao.update(alert);
				
				//Audit
				//审核结果
				if(!CreditCommUtils.strEqual(approveStatusChoose_old,approveStatusChoose)){
					CreditCardAuditTrail audit = new CreditCardAuditTrail();
					audit.setId(CreditCommUtils.getUUID());
					audit.setAlarmNo(alert.getAlarmNo());
					audit.setFieldName("审核结果");
					audit.setOldValue(CreditConstant.ApproveStatus.getShow(approveStatusChoose_old));
					audit.setNewValue(CreditConstant.ApproveStatus.getShow(approveStatusChoose));
					audit.setOperatorTlr(gi.getTlrno());
					audit.setOperatorTime(sdf.format(new Date()));
					rootDao.save(audit);
				}
				
				//审核说明
				if(!CreditCommUtils.strEqual(approveMemoChoose_old,approveMemoChoose)){
					CreditCardAuditTrail audit2 = new CreditCardAuditTrail();
					audit2.setId(CreditCommUtils.getUUID());
					audit2.setAlarmNo(alert.getAlarmNo());
					audit2.setFieldName("审核说明");
					audit2.setOldValue(approveMemoChoose_old);
					audit2.setNewValue(approveMemoChoose);
					audit2.setOperatorTlr(gi.getTlrno());
					audit2.setOperatorTime(sdf.format(new Date()));
					rootDao.save(audit2);
				}
			}
		}
	}

	@Override
	public void afterProc(OperationContext context) throws CommonException {
		// TODO Auto-generated method stub
		
	}
}
