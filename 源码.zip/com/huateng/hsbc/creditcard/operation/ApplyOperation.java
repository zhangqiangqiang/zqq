package com.huateng.hsbc.creditcard.operation;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.huateng.ebank.business.common.ErrorCode;
import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.exceptions.CommonException;
import com.huateng.ebank.framework.operation.BaseOperation;
import com.huateng.ebank.framework.operation.OperationContext;
import com.huateng.ebank.framework.util.ExceptionUtil;
import com.huateng.hsbc.creditcard.bean.CreditCardAlert;
import com.huateng.hsbc.creditcard.utils.CreditCommUtils;
import com.huateng.hsbc.creditcard.utils.CreditConstant;

public class ApplyOperation  extends BaseOperation{
	public static final String ID = "ApplyOperation";
	public static final String IDS = "IDS";
	public static final String TYPE = "TYPE";
	
	public static final String TYPE_1 = "TYPE_APPLY";
	public static final String TYPE_2 = "TYPE_APPROVE_APPLY";
	
	public static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
	
	@Override
	public void beforeProc(OperationContext context) throws CommonException {
		String type = (String) context.getAttribute(TYPE);
		String ids = (String) context.getAttribute(IDS);
		ROOTDAO rootDao= ROOTDAOUtils.getROOTDAO();
		String[] idArr = ids.split(",");
		if(TYPE_1.equals(type)){
			for(String id : idArr){
				CreditCardAlert alert = rootDao.query(CreditCardAlert.class, id);
				if(CreditCommUtils.isNotEmpty(alert.getOperatorTlr())){
					ExceptionUtil.throwCommonException2("存在已经被申领的记录");
				}
			}
		}
	}

	@Override
	public void execute(OperationContext context) throws CommonException {
		String type = (String) context.getAttribute(TYPE);
		String ids = (String) context.getAttribute(IDS);
		String[] idArr = ids.split(",");
		GlobalInfo gi = GlobalInfo.getCurrentInstance();
		ROOTDAO rootDao= ROOTDAOUtils.getROOTDAO();
		if(TYPE_1.equals(type)){
			for(String id : idArr){
				CreditCardAlert alert = rootDao.query(CreditCardAlert.class, id);
				alert.setRecStatus(CreditConstant.RecStatus.STATUS_01.getValue());
				alert.setOperatorTlr(gi.getTlrno());
				alert.setOpenAlerttime(sdf.format(new Date()));
				rootDao.update(alert);
			}
		}else{
			for(String id : idArr){
				CreditCardAlert alert = rootDao.query(CreditCardAlert.class, id);
				alert.setRecStatus(CreditConstant.RecStatus.STATUS_04.getValue());
				alert.setApproveTlr(gi.getTlrno());
				rootDao.update(alert);
			}
		}
	}

	@Override
	public void afterProc(OperationContext context) throws CommonException {
		// TODO Auto-generated method stub
		
	}

}
