package com.huateng.hsbc.creditcard.dwr;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;

import resource.bean.report.SysParams;

import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.exceptions.CommonException;
import com.huateng.hsbc.creditcard.bean.CreditCardAlert;
import com.huateng.hsbc.creditcard.bean.CreditCardAuditTrail;
import com.huateng.hsbc.creditcard.bean.CreditCardMsg;
import com.huateng.hsbc.creditcard.bean.CreditCardProof;
import com.huateng.hsbc.creditcard.bean.CreditCardTrade;
import com.huateng.hsbc.creditcard.utils.CreditCommUtils;
import com.huateng.hsbc.creditcard.utils.CreditConstant;
import com.huateng.report.common.service.ReportCommonService;
import com.huateng.report.utils.ReportUtils;

public class CreditCardDwrFunction {
	
	public String getNextCase(String id,String level,String qs,String qe) throws CommonException{
		GlobalInfo globalInfo = GlobalInfo.getCurrentInstance();
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		//查询当前部门所有未申领的交易
		StringBuilder hql = new StringBuilder( "from CreditCardAlert where recStatus = '01' ");
		hql.append(" AND operatorTlr ='"+globalInfo.getTlrno()+"'");
		hql.append(" AND riskLevel ='"+level+"'");
		hql.append(" AND alarmDate >= '"+qs+"'");
		hql.append(" AND alarmDate <= '"+qe+"'");
		hql.append(" order by alarmDate desc,alarmNo");
		
		List<CreditCardAlert> list = rootdao.queryByQL2List(hql.toString());
		for(int i=0;i<list.size();i++){
			CreditCardAlert alert = list.get(i);
			if(alert.getId().equals(id)){
				if(i==list.size()-1){
					return null;
				}else{
					return list.get(i+1).getId();
				}
			}
		}
		return null;
	}
	
	public Map<String,String> getMsgInfoByType(String msgType,CreditCardTrade trade)throws CommonException{
		Map<String,String> resultMap = new HashMap<String,String>();
		if("".equals(msgType)||"NA".equals(msgType)){
			resultMap.put("msgInfo", "");
			resultMap.put("serverInfo", "");
		}else{
			SysParams param = ReportCommonService.getInstance().getSysparamsByPk("MSGINFO", msgType);
			String msgInfo = param.getParamVal();
			msgInfo = msgInfo.replaceAll("@DATE@", trade.getTradeDate());
			msgInfo = msgInfo.replaceAll("@AMT@", trade.getTradeAmt().toString());
			msgInfo = msgInfo.replaceAll("@MERCHANTNAME@", trade.getMerchantName());
			resultMap.put("msgInfo", msgInfo);
			
			String serverInfo = param.getParamName();
			resultMap.put("serverInfo", serverInfo);
		}
		return resultMap;
	}
	
	public String applyCase(String level)throws CommonException{
		String result = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		GlobalInfo globalInfo = GlobalInfo.getCurrentInstance();
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		SysParams param = ReportCommonService.getInstance().getSysparamsByPk("SHENLING", "CREDIT");
	    if (!"0".equals(param.getParamVal())) {
	    	result = "1";// "已有用户正在进行申领，请稍后重试！";
	    }
	    param.setParamVal("1");
	    param.setParamName(globalInfo.getTlrno());
	    rootdao.saveOrUpdate(param);
		//查询待申领记录
	    StringBuilder hql = new StringBuilder( "from CreditCardAlert where recStatus = '00' ");
		hql.append(" AND riskLevel ='"+level+"'");
		hql.append(" order by alarmDate,alarmNo");
		List<CreditCardAlert> list = rootdao.queryByQL2List(hql.toString());
		if(list!=null&&list.size()>0){
			CreditCardAlert alert  = list.get(0);
			alert.setRecStatus(CreditConstant.RecStatus.STATUS_01.getValue());
			alert.setOperatorTlr(globalInfo.getTlrno());
			alert.setOpenAlerttime(sdf.format(new Date()));
			rootdao.update(alert);
//			result = "0";// "申领成功！";
			StringBuffer show = new StringBuffer();
			show.append("申领成功！告警日期[").append(alert.getAlarmDate()).append("]");
			show.append("告警号[").append(alert.getAlarmNo()).append("]");
			result = show.toString();
		}else{
			result = "2"; //"未查询到待申领的记录！";
		}
		
	    param.setParamVal("0");
	    rootdao.saveOrUpdate(param);
	    return result;
	}
	
	public String deleteMsg(String ids)throws CommonException{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		GlobalInfo gi = GlobalInfo.getCurrentInstance();
		ROOTDAO rootDao= ROOTDAOUtils.getROOTDAO();
		
		String[] idArr = ids.split(",");
		for(String id : idArr){
			CreditCardMsg msg = rootDao.query(CreditCardMsg.class, id);
			
			//Audit
			CreditCardAuditTrail audit = new CreditCardAuditTrail();
			audit.setId(CreditCommUtils.getUUID());
			audit.setAlarmNo(msg.getAlarmNo());
			audit.setFieldName("短信内容");
			audit.setOldValue(CreditCommUtils.getDataDic(msg.getMsgType(), "1004"));
			audit.setNewValue(null);
			audit.setOperatorTlr(gi.getTlrno());
			audit.setOperatorTime(sdf.format(new Date()));
			rootDao.save(audit);
			
			rootDao.delete(msg);
		}
		return "";
	}
	
	public String deleteProof(String proofId)throws CommonException{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		GlobalInfo gi = GlobalInfo.getCurrentInstance();
		ROOTDAO rootDao= ROOTDAOUtils.getROOTDAO();
		
		CreditCardProof proof = rootDao.query(CreditCardProof.class, proofId);
		proof.setStatus(CreditConstant.Flag.Flag_1.getValue());
		//Audit
		CreditCardAuditTrail audit = new CreditCardAuditTrail();
		audit.setId(CreditCommUtils.getUUID());
		audit.setAlarmNo(proof.getAlarmNo());
		audit.setFieldName("凭证文件");
		audit.setOldValue(proof.getProofName());
		audit.setNewValue("删除");
		audit.setOperatorTlr(gi.getTlrno());
		audit.setOperatorTime(sdf.format(new Date()));
		rootDao.save(audit);
		
		rootDao.update(proof);
		
		return "";
	}
}
