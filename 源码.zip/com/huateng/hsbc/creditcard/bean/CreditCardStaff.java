package com.huateng.hsbc.creditcard.bean;

import java.math.BigDecimal;

public class CreditCardStaff {
	private String id;
	private String showDate;
	private String operatorNo;
	private String operatorName;
	private BigDecimal openAlert;
	private BigDecimal closeAlert;
	
	public String getShowDate() {
		return showDate;
	}
	public void setShowDate(String showDate) {
		this.showDate = showDate;
	}
	public String getOperatorNo() {
		return operatorNo;
	}
	public void setOperatorNo(String operatorNo) {
		this.operatorNo = operatorNo;
	}
	public String getOperatorName() {
		return operatorName;
	}
	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}
	public BigDecimal getOpenAlert() {
		return openAlert;
	}
	public void setOpenAlert(BigDecimal openAlert) {
		this.openAlert = openAlert;
	}
	public BigDecimal getCloseAlert() {
		return closeAlert;
	}
	public void setCloseAlert(BigDecimal closeAlert) {
		this.closeAlert = closeAlert;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
}
