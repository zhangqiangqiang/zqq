package com.huateng.hsbc.creditcard.bean;

import java.math.BigDecimal;

public class CreditCardOverView {
	private String alarmDate;
	private BigDecimal generateAlert;
	private BigDecimal openAlert;
	private BigDecimal closeAlert;
	public String getAlarmDate() {
		return alarmDate;
	}
	public void setAlarmDate(String alarmDate) {
		this.alarmDate = alarmDate;
	}
	public BigDecimal getGenerateAlert() {
		return generateAlert;
	}
	public void setGenerateAlert(BigDecimal generateAlert) {
		this.generateAlert = generateAlert;
	}
	public BigDecimal getOpenAlert() {
		return openAlert;
	}
	public void setOpenAlert(BigDecimal openAlert) {
		this.openAlert = openAlert;
	}
	public BigDecimal getCloseAlert() {
		return closeAlert;
	}
	public void setCloseAlert(BigDecimal closeAlert) {
		this.closeAlert = closeAlert;
	}
}
