package com.huateng.hsbc.creditcard.bean;

import java.math.BigDecimal;

public class SendAgentSystem {
	private BigDecimal rec_id;
	private String alarm_date     ; 
	private String cust_cert_no    ;
	private String cust_cert_type  ;
	private String service_name   ;
	private String service_comment;
	private String service_date   ;
	private String service_time   ;
	private String service_no     ;
	private String report_date;
	public BigDecimal getRec_id() {
		return rec_id;
	}
	public void setRec_id(BigDecimal rec_id) {
		this.rec_id = rec_id;
	}
	public String getAlarm_date() {
		return alarm_date;
	}
	public void setAlarm_date(String alarm_date) {
		this.alarm_date = alarm_date;
	}
	public String getCust_cert_no() {
		return cust_cert_no;
	}
	public void setCust_cert_no(String cust_cert_no) {
		this.cust_cert_no = cust_cert_no;
	}
	public String getCust_cert_type() {
		return cust_cert_type;
	}
	public void setCust_cert_type(String cust_cert_type) {
		this.cust_cert_type = cust_cert_type;
	}
	public String getService_name() {
		return service_name;
	}
	public void setService_name(String service_name) {
		this.service_name = service_name;
	}
	public String getService_comment() {
		return service_comment;
	}
	public void setService_comment(String service_comment) {
		this.service_comment = service_comment;
	}
	public String getService_date() {
		return service_date;
	}
	public void setService_date(String service_date) {
		this.service_date = service_date;
	}
	public String getService_time() {
		return service_time;
	}
	public void setService_time(String service_time) {
		this.service_time = service_time;
	}
	public String getService_no() {
		return service_no;
	}
	public void setService_no(String service_no) {
		this.service_no = service_no;
	}
	public String getReport_date() {
		return report_date;
	}
	public void setReport_date(String report_date) {
		this.report_date = report_date;
	}
	public SendAgentSystem() {
		super();
	}
	public SendAgentSystem(BigDecimal rec_id, String alarm_date,
			String cust_cert_no, String cust_cert_type, String service_name,
			String service_comment, String service_date, String service_time,
			String service_no, String report_date) {
		super();
		this.rec_id = rec_id;
		this.alarm_date = alarm_date;
		this.cust_cert_no = cust_cert_no;
		this.cust_cert_type = cust_cert_type;
		this.service_name = service_name;
		this.service_comment = service_comment;
		this.service_date = service_date;
		this.service_time = service_time;
		this.service_no = service_no;
		this.report_date = report_date;
	}
	
}
