package com.huateng.hsbc.creditcard.bean;

import java.math.BigDecimal;

public class CreditTransactionDetail {
	private BigDecimal rec_id                  ;
	private String     batch_no                ; 
	private String     alert_id                ;
	private String     risk_level              ;
	private String     cust_no                 ;
	private String     card_number             ;
	private String     id_type                 ;
	private String     id_number               ;
	private String     cardholder_name         ;
	private String     company_name            ;
	private String     customer_category       ;
	private BigDecimal billing_date            ;
	private String     repayment_date          ;
	private BigDecimal income                  ;
	private String     bureau_score            ;
	private String     recent_cld_time         ;
	private String     mobile_phon             ;
	private BigDecimal credit_card_limit       ;
	private BigDecimal available_balance       ;
	private String     transaction_date        ;
	private String     transaction_time        ;
	private BigDecimal transaction_amount      ;
	private String     transaction_currency    ;
	private String     transaction_country     ;
	private String     transaction_city        ;
	private String     mcc_code                ;
	private String     merchant_name           ;
	private String     merchant_id             ;
	private String     terminal_id             ;
	private String     pos_entry_mode          ;
	private String     if_apple_pay            ;
	public BigDecimal getRec_id() {
		return rec_id;
	}
	public void setRec_id(BigDecimal rec_id) {
		this.rec_id = rec_id;
	}
	public String getBatch_no() {
		return batch_no;
	}
	public void setBatch_no(String batch_no) {
		this.batch_no = batch_no;
	}
	public String getAlert_id() {
		return alert_id;
	}
	public void setAlert_id(String alert_id) {
		this.alert_id = alert_id;
	}
	public String getRisk_level() {
		return risk_level;
	}
	public void setRisk_level(String risk_level) {
		this.risk_level = risk_level;
	}
	public String getCust_no() {
		return cust_no;
	}
	public void setCust_no(String cust_no) {
		this.cust_no = cust_no;
	}
	public String getCard_number() {
		return card_number;
	}
	public void setCard_number(String card_number) {
		this.card_number = card_number;
	}
	public String getId_type() {
		return id_type;
	}
	public void setId_type(String id_type) {
		this.id_type = id_type;
	}
	public String getId_number() {
		return id_number;
	}
	public void setId_number(String id_number) {
		this.id_number = id_number;
	}
	public String getCardholder_name() {
		return cardholder_name;
	}
	public void setCardholder_name(String cardholder_name) {
		this.cardholder_name = cardholder_name;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String getCustomer_category() {
		return customer_category;
	}
	public void setCustomer_category(String customer_category) {
		this.customer_category = customer_category;
	}
	public BigDecimal getBilling_date() {
		return billing_date;
	}
	public void setBilling_date(BigDecimal billing_date) {
		this.billing_date = billing_date;
	}
	public String getRepayment_date() {
		return repayment_date;
	}
	public void setRepayment_date(String repayment_date) {
		this.repayment_date = repayment_date;
	}
	public BigDecimal getIncome() {
		return income;
	}
	public void setIncome(BigDecimal income) {
		this.income = income;
	}
	public String getBureau_score() {
		return bureau_score;
	}
	public void setBureau_score(String bureau_score) {
		this.bureau_score = bureau_score;
	}
	public String getRecent_cld_time() {
		return recent_cld_time;
	}
	public void setRecent_cld_time(String recent_cld_time) {
		this.recent_cld_time = recent_cld_time;
	}
	public String getMobile_phon() {
		return mobile_phon;
	}
	public void setMobile_phon(String mobile_phon) {
		this.mobile_phon = mobile_phon;
	}
	public BigDecimal getCredit_card_limit() {
		return credit_card_limit;
	}
	public void setCredit_card_limit(BigDecimal credit_card_limit) {
		this.credit_card_limit = credit_card_limit;
	}
	public BigDecimal getAvailable_balance() {
		return available_balance;
	}
	public void setAvailable_balance(BigDecimal available_balance) {
		this.available_balance = available_balance;
	}
	public String getTransaction_date() {
		return transaction_date;
	}
	public void setTransaction_date(String transaction_date) {
		this.transaction_date = transaction_date;
	}
	public String getTransaction_time() {
		return transaction_time;
	}
	public void setTransaction_time(String transaction_time) {
		this.transaction_time = transaction_time;
	}
	public BigDecimal getTransaction_amount() {
		return transaction_amount;
	}
	public void setTransaction_amount(BigDecimal transaction_amount) {
		this.transaction_amount = transaction_amount;
	}
	public String getTransaction_currency() {
		return transaction_currency;
	}
	public void setTransaction_currency(String transaction_currency) {
		this.transaction_currency = transaction_currency;
	}
	public String getTransaction_country() {
		return transaction_country;
	}
	public void setTransaction_country(String transaction_country) {
		this.transaction_country = transaction_country;
	}
	public String getTransaction_city() {
		return transaction_city;
	}
	public void setTransaction_city(String transaction_city) {
		this.transaction_city = transaction_city;
	}
	public String getMcc_code() {
		return mcc_code;
	}
	public void setMcc_code(String mcc_code) {
		this.mcc_code = mcc_code;
	}
	public String getMerchant_name() {
		return merchant_name;
	}
	public void setMerchant_name(String merchant_name) {
		this.merchant_name = merchant_name;
	}
	public String getMerchant_id() {
		return merchant_id;
	}
	public void setMerchant_id(String merchant_id) {
		this.merchant_id = merchant_id;
	}
	public String getTerminal_id() {
		return terminal_id;
	}
	public void setTerminal_id(String terminal_id) {
		this.terminal_id = terminal_id;
	}
	public String getPos_entry_mode() {
		return pos_entry_mode;
	}
	public void setPos_entry_mode(String pos_entry_mode) {
		this.pos_entry_mode = pos_entry_mode;
	}
	public String getIf_apple_pay() {
		return if_apple_pay;
	}
	public void setIf_apple_pay(String if_apple_pay) {
		this.if_apple_pay = if_apple_pay;
	}
	
}
