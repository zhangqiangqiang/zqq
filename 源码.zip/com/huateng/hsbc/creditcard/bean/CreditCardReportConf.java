package com.huateng.hsbc.creditcard.bean;

public class CreditCardReportConf {
	private String id;
	private String reportId;
	private String reportName;
	private String fieldName;
	private String fieldDesc;
	private String fieldType;
	private String fieldDic;
	private int fieldIndex;
	private String rsv1             ;
	private String rsv2             ;
	private String rsv3             ;
	private String rsv4             ;
	private String rsv5             ;
	private String rsv6             ;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getReportId() {
		return reportId;
	}
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}
	public String getReportName() {
		return reportName;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getFieldDesc() {
		return fieldDesc;
	}
	public void setFieldDesc(String fieldDesc) {
		this.fieldDesc = fieldDesc;
	}
	public String getFieldType() {
		return fieldType;
	}
	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}
	public String getFieldDic() {
		return fieldDic;
	}
	public void setFieldDic(String fieldDic) {
		this.fieldDic = fieldDic;
	}
	public int getFieldIndex() {
		return fieldIndex;
	}
	public void setFieldIndex(int fieldIndex) {
		this.fieldIndex = fieldIndex;
	}
	public String getRsv1() {
		return rsv1;
	}
	public void setRsv1(String rsv1) {
		this.rsv1 = rsv1;
	}
	public String getRsv2() {
		return rsv2;
	}
	public void setRsv2(String rsv2) {
		this.rsv2 = rsv2;
	}
	public String getRsv3() {
		return rsv3;
	}
	public void setRsv3(String rsv3) {
		this.rsv3 = rsv3;
	}
	public String getRsv4() {
		return rsv4;
	}
	public void setRsv4(String rsv4) {
		this.rsv4 = rsv4;
	}
	public String getRsv5() {
		return rsv5;
	}
	public void setRsv5(String rsv5) {
		this.rsv5 = rsv5;
	}
	public String getRsv6() {
		return rsv6;
	}
	public void setRsv6(String rsv6) {
		this.rsv6 = rsv6;
	}
}
