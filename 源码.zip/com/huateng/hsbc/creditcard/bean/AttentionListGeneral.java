package com.huateng.hsbc.creditcard.bean;

import java.math.BigDecimal;

public class AttentionListGeneral {
	private BigDecimal rec_id;
	private String alarm_date  ; 
	private String alarm_no    ;
	private String cust_no     ;
	private String cust_name   ;
	private String cust_phone_no;
	private String id_no;
	private String id_type;
	private String send_time;
	public BigDecimal getRec_id() {
		return rec_id;
	}
	public void setRec_id(BigDecimal rec_id) {
		this.rec_id = rec_id;
	}
	public String getAlarm_date() {
		return alarm_date;
	}
	public void setAlarm_date(String alarm_date) {
		this.alarm_date = alarm_date;
	}
	public String getAlarm_no() {
		return alarm_no;
	}
	public void setAlarm_no(String alarm_no) {
		this.alarm_no = alarm_no;
	}
	public String getCust_no() {
		return cust_no;
	}
	public void setCust_no(String cust_no) {
		this.cust_no = cust_no;
	}
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public String getCust_phone_no() {
		return cust_phone_no;
	}
	public void setCust_phone_no(String cust_phone_no) {
		this.cust_phone_no = cust_phone_no;
	}
	public String getId_no() {
		return id_no;
	}
	public void setId_no(String id_no) {
		this.id_no = id_no;
	}
	public String getId_type() {
		return id_type;
	}
	public void setId_type(String id_type) {
		this.id_type = id_type;
	}
	public String getSend_time() {
		return send_time;
	}
	public void setSend_time(String send_time) {
		this.send_time = send_time;
	}
}
