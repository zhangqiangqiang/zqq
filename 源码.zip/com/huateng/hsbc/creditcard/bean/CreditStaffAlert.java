package com.huateng.hsbc.creditcard.bean;

import java.math.BigDecimal;

public class CreditStaffAlert {
	private BigDecimal rec_id             ;
	private String alarm_date         ;
	private String alarm_no           ;
	private String cust_no            ;
	private String cust_name          ;
	private String cust_cert_type     ;
	private String cust_cert_no       ;
	private String cust_category      ;
	private String cust_phone_no      ;
	private String cust_work_unit     ;
	private String cust_income        ;
	private String credit_card_cny    ;
	private String active_time_cny    ;
	private String credit_card_usd    ;
	private String active_time_usd    ;
	private BigDecimal limit_cny          ;
	private BigDecimal limit_available_cny;
	private String billing_date       ;
	private String billing_address    ;
	private String repay_date         ;
	private String first_reduce_time  ;
	private String transactor_no      ;
	private String proof_result       ;
	private String merchant_result    ;
	private String outbound_result    ;
	private String investigate_result ;
	private String investigate_report ;
	private String staff_no           ;
	private String close_alert_time;
	public BigDecimal getRec_id() {
		return rec_id;
	}
	public void setRec_id(BigDecimal rec_id) {
		this.rec_id = rec_id;
	}
	public String getAlarm_date() {
		return alarm_date;
	}
	public void setAlarm_date(String alarm_date) {
		this.alarm_date = alarm_date;
	}
	public String getAlarm_no() {
		return alarm_no;
	}
	public void setAlarm_no(String alarm_no) {
		this.alarm_no = alarm_no;
	}
	public String getCust_no() {
		return cust_no;
	}
	public void setCust_no(String cust_no) {
		this.cust_no = cust_no;
	}
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public String getCust_cert_type() {
		return cust_cert_type;
	}
	public void setCust_cert_type(String cust_cert_type) {
		this.cust_cert_type = cust_cert_type;
	}
	public String getCust_cert_no() {
		return cust_cert_no;
	}
	public void setCust_cert_no(String cust_cert_no) {
		this.cust_cert_no = cust_cert_no;
	}
	public String getCust_category() {
		return cust_category;
	}
	public void setCust_category(String cust_category) {
		this.cust_category = cust_category;
	}
	public String getCust_phone_no() {
		return cust_phone_no;
	}
	public void setCust_phone_no(String cust_phone_no) {
		this.cust_phone_no = cust_phone_no;
	}
	public String getCust_work_unit() {
		return cust_work_unit;
	}
	public void setCust_work_unit(String cust_work_unit) {
		this.cust_work_unit = cust_work_unit;
	}
	public String getCust_income() {
		return cust_income;
	}
	public void setCust_income(String cust_income) {
		this.cust_income = cust_income;
	}
	public String getCredit_card_cny() {
		return credit_card_cny;
	}
	public void setCredit_card_cny(String credit_card_cny) {
		this.credit_card_cny = credit_card_cny;
	}
	public String getActive_time_cny() {
		return active_time_cny;
	}
	public void setActive_time_cny(String active_time_cny) {
		this.active_time_cny = active_time_cny;
	}
	public String getCredit_card_usd() {
		return credit_card_usd;
	}
	public void setCredit_card_usd(String credit_card_usd) {
		this.credit_card_usd = credit_card_usd;
	}
	public String getActive_time_usd() {
		return active_time_usd;
	}
	public void setActive_time_usd(String active_time_usd) {
		this.active_time_usd = active_time_usd;
	}
	public BigDecimal getLimit_cny() {
		return limit_cny;
	}
	public void setLimit_cny(BigDecimal limit_cny) {
		this.limit_cny = limit_cny;
	}
	public BigDecimal getLimit_available_cny() {
		return limit_available_cny;
	}
	public void setLimit_available_cny(BigDecimal limit_available_cny) {
		this.limit_available_cny = limit_available_cny;
	}
	public String getBilling_date() {
		return billing_date;
	}
	public void setBilling_date(String billing_date) {
		this.billing_date = billing_date;
	}
	public String getBilling_address() {
		return billing_address;
	}
	public void setBilling_address(String billing_address) {
		this.billing_address = billing_address;
	}
	public String getRepay_date() {
		return repay_date;
	}
	public void setRepay_date(String repay_date) {
		this.repay_date = repay_date;
	}
	public String getFirst_reduce_time() {
		return first_reduce_time;
	}
	public void setFirst_reduce_time(String first_reduce_time) {
		this.first_reduce_time = first_reduce_time;
	}
	public String getTransactor_no() {
		return transactor_no;
	}
	public void setTransactor_no(String transactor_no) {
		this.transactor_no = transactor_no;
	}
	public String getProof_result() {
		return proof_result;
	}
	public void setProof_result(String proof_result) {
		this.proof_result = proof_result;
	}
	public String getMerchant_result() {
		return merchant_result;
	}
	public void setMerchant_result(String merchant_result) {
		this.merchant_result = merchant_result;
	}
	public String getOutbound_result() {
		return outbound_result;
	}
	public void setOutbound_result(String outbound_result) {
		this.outbound_result = outbound_result;
	}
	public String getInvestigate_result() {
		return investigate_result;
	}
	public void setInvestigate_result(String investigate_result) {
		this.investigate_result = investigate_result;
	}
	public String getInvestigate_report() {
		return investigate_report;
	}
	public void setInvestigate_report(String investigate_report) {
		this.investigate_report = investigate_report;
	}
	public String getStaff_no() {
		return staff_no;
	}
	public void setStaff_no(String staff_no) {
		this.staff_no = staff_no;
	}
	public String getClose_alert_time() {
		return close_alert_time;
	}
	public void setClose_alert_time(String close_alert_time) {
		this.close_alert_time = close_alert_time;
	}
	
}
