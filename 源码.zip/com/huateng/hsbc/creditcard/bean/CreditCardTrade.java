package com.huateng.hsbc.creditcard.bean;

import java.math.BigDecimal;

public class CreditCardTrade {
	private String id;
	private String custNo      ;
	private String creditCard  ;
	private String tradeDate   ;
	private String tradeTime   ;
	private String tradeCur    ;
	private BigDecimal tradeAmt;
	private String tradeCity   ;
	private String mccCode     ;
	private String merchantName;
	private String merchantId  ;
	private String terminalId  ;
	private String posEntrymode;
	private String applePay    ;
	private String alarmNo     ;
	private String rsv1             ;
	private String rsv2             ;
	private String rsv3             ;
	private String rsv4             ;
	private String rsv5             ;
	private String rsv6             ;
	
	private boolean selectBackGround;
	
	public boolean isSelectBackGround() {
		return selectBackGround;
	}
	public void setSelectBackGround(boolean selectBackGround) {
		this.selectBackGround = selectBackGround;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCustNo() {
		return custNo;
	}
	public void setCustNo(String custNo) {
		this.custNo = custNo;
	}
	public String getCreditCard() {
		return creditCard;
	}
	public void setCreditCard(String creditCard) {
		this.creditCard = creditCard;
	}
	public String getTradeDate() {
		return tradeDate;
	}
	public void setTradeDate(String tradeDate) {
		this.tradeDate = tradeDate;
	}
	public String getTradeTime() {
		return tradeTime;
	}
	public void setTradeTime(String tradeTime) {
		this.tradeTime = tradeTime;
	}
	public String getTradeCur() {
		return tradeCur;
	}
	public void setTradeCur(String tradeCur) {
		this.tradeCur = tradeCur;
	}
	public BigDecimal getTradeAmt() {
		return tradeAmt;
	}
	public void setTradeAmt(BigDecimal tradeAmt) {
		this.tradeAmt = tradeAmt;
	}
	public String getTradeCity() {
		return tradeCity;
	}
	public void setTradeCity(String tradeCity) {
		this.tradeCity = tradeCity;
	}
	public String getMccCode() {
		return mccCode;
	}
	public void setMccCode(String mccCode) {
		this.mccCode = mccCode;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}
	public String getTerminalId() {
		return terminalId;
	}
	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}
	public String getPosEntrymode() {
		return posEntrymode;
	}
	public void setPosEntrymode(String posEntrymode) {
		this.posEntrymode = posEntrymode;
	}
	public String getApplePay() {
		return applePay;
	}
	public void setApplePay(String applePay) {
		this.applePay = applePay;
	}
	public String getAlarmNo() {
		return alarmNo;
	}
	public void setAlarmNo(String alarmNo) {
		this.alarmNo = alarmNo;
	}
	public String getRsv1() {
		return rsv1;
	}
	public void setRsv1(String rsv1) {
		this.rsv1 = rsv1;
	}
	public String getRsv2() {
		return rsv2;
	}
	public void setRsv2(String rsv2) {
		this.rsv2 = rsv2;
	}
	public String getRsv3() {
		return rsv3;
	}
	public void setRsv3(String rsv3) {
		this.rsv3 = rsv3;
	}
	public String getRsv4() {
		return rsv4;
	}
	public void setRsv4(String rsv4) {
		this.rsv4 = rsv4;
	}
	public String getRsv5() {
		return rsv5;
	}
	public void setRsv5(String rsv5) {
		this.rsv5 = rsv5;
	}
	public String getRsv6() {
		return rsv6;
	}
	public void setRsv6(String rsv6) {
		this.rsv6 = rsv6;
	}
}
