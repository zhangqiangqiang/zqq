package com.huateng.hsbc.creditcard.bean;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class CaseManagementReport {
	
	private String id;
	private String alarmDate        ;
	private String alarmNo          ;
	private String ruleName         ;
	private String riskLevel        ;
	private String isAlertm         ;
	private String custNo           ;
	private String custName         ;
	private String custGender       ;
	private String custCerttype     ;
	private String custCertno       ;
	private String custCategory     ;
	private String custPhoneno      ;
	private String custWorkunit     ;
	private String custIncome       ;
	private String creditCardcny    ;
	private String activeTimecny    ;
	private String creditCardusd    ;
	private String activeTimeusd    ;
	private BigDecimal limitCny         ;
	private BigDecimal limitAvailablecny;
	private String billingDate      ;
	private String billingAddress   ;
	private String repayDate        ;
	private String pbcScore         ;
	private String firstReducetime  ;
	private String transactorNo     ;
	private String proofResult      ;
	private String merchantResult   ;
	private String outboundResult   ;
	private String investigateResult;
	private String investigateReport;
	private String fcUar            ;
	private String messageResult    ;
	private String billStage        ;
	private String reduce           ;
	private String cardFreeze       ;
	private String approveStatus    ;
	private String approveMemo      ;
	private String approveTlr       ;
	private String operatorTlr      ;
	private String openAlerttime    ;
	private String closeAlerttime   ;
	private String reOpenalertTime  ;
	private String reClosealertTime ;
	private String recStatus        ;
	private String checkFlag        ;
	private String rsv1             ;
	private String rsv2             ;
	private String rsv3             ;
	private String rsv4             ;
	private String rsv5             ;
	private String rsv6             ;
	
	private String operatorTlrName  ;
	
	public String getOperatorTlrName() {
		return operatorTlrName;
	}
	public void setOperatorTlrName(String operatorTlrName) {
		this.operatorTlrName = operatorTlrName;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAlarmDate() {
		return alarmDate;
	}
	public void setAlarmDate(String alarmDate) {
		this.alarmDate = alarmDate;
	}
	public String getAlarmNo() {
		return alarmNo;
	}
	public void setAlarmNo(String alarmNo) {
		this.alarmNo = alarmNo;
	}
	public String getRuleName() {
		return ruleName;
	}
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}
	public String getRiskLevel() {
		return riskLevel;
	}
	public void setRiskLevel(String riskLevel) {
		this.riskLevel = riskLevel;
	}
	public String getIsAlertm() {
		return isAlertm;
	}
	public void setIsAlertm(String isAlertm) {
		this.isAlertm = isAlertm;
	}
	public String getCustNo() {
		return custNo;
	}
	public void setCustNo(String custNo) {
		this.custNo = custNo;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustGender() {
		return custGender;
	}
	public void setCustGender(String custGender) {
		this.custGender = custGender;
	}
	public String getCustCerttype() {
		return custCerttype;
	}
	public void setCustCerttype(String custCerttype) {
		this.custCerttype = custCerttype;
	}
	public String getCustCertno() {
		return custCertno;
	}
	public void setCustCertno(String custCertno) {
		this.custCertno = custCertno;
	}
	public String getCustCategory() {
		return custCategory;
	}
	public void setCustCategory(String custCategory) {
		this.custCategory = custCategory;
	}
	public String getCustPhoneno() {
		return custPhoneno;
	}
	public void setCustPhoneno(String custPhoneno) {
		this.custPhoneno = custPhoneno;
	}
	public String getCustWorkunit() {
		return custWorkunit;
	}
	public void setCustWorkunit(String custWorkunit) {
		this.custWorkunit = custWorkunit;
	}
	public String getCustIncome() {
		return custIncome;
	}
	public void setCustIncome(String custIncome) {
		this.custIncome = custIncome;
	}
	public String getCreditCardcny() {
		return creditCardcny;
	}
	public void setCreditCardcny(String creditCardcny) {
		this.creditCardcny = creditCardcny;
	}
	public String getActiveTimecny() {
		return activeTimecny;
	}
	public void setActiveTimecny(String activeTimecny) {
		this.activeTimecny = activeTimecny;
	}
	public String getCreditCardusd() {
		return creditCardusd;
	}
	public void setCreditCardusd(String creditCardusd) {
		this.creditCardusd = creditCardusd;
	}
	public String getActiveTimeusd() {
		return activeTimeusd;
	}
	public void setActiveTimeusd(String activeTimeusd) {
		this.activeTimeusd = activeTimeusd;
	}
	public BigDecimal getLimitCny() {
		return limitCny;
	}
	public void setLimitCny(BigDecimal limitCny) {
		this.limitCny = limitCny;
	}
	public BigDecimal getLimitAvailablecny() {
		return limitAvailablecny;
	}
	public void setLimitAvailablecny(BigDecimal limitAvailablecny) {
		this.limitAvailablecny = limitAvailablecny;
	}
	public String getBillingDate() {
		return billingDate;
	}
	public void setBillingDate(String billingDate) {
		this.billingDate = billingDate;
	}
	public String getBillingAddress() {
		return billingAddress;
	}
	public void setBillingAddress(String billingAddress) {
		this.billingAddress = billingAddress;
	}
	public String getRepayDate() {
		return repayDate;
	}
	public void setRepayDate(String repayDate) {
		this.repayDate = repayDate;
	}
	public String getPbcScore() {
		return pbcScore;
	}
	public void setPbcScore(String pbcScore) {
		this.pbcScore = pbcScore;
	}
	public String getFirstReducetime() {
		return firstReducetime;
	}
	public void setFirstReducetime(String firstReducetime) {
		this.firstReducetime = firstReducetime;
	}
	public String getTransactorNo() {
		return transactorNo;
	}
	public void setTransactorNo(String transactorNo) {
		this.transactorNo = transactorNo;
	}
	public String getProofResult() {
		return proofResult;
	}
	public void setProofResult(String proofResult) {
		this.proofResult = proofResult;
	}
	public String getMerchantResult() {
		return merchantResult;
	}
	public void setMerchantResult(String merchantResult) {
		this.merchantResult = merchantResult;
	}
	public String getOutboundResult() {
		return outboundResult;
	}
	public void setOutboundResult(String outboundResult) {
		this.outboundResult = outboundResult;
	}
	public String getInvestigateResult() {
		return investigateResult;
	}
	public void setInvestigateResult(String investigateResult) {
		this.investigateResult = investigateResult;
	}
	public String getInvestigateReport() {
		return investigateReport;
	}
	public void setInvestigateReport(String investigateReport) {
		this.investigateReport = investigateReport;
	}
	public String getFcUar() {
		return fcUar;
	}
	public void setFcUar(String fcUar) {
		this.fcUar = fcUar;
	}
	public String getMessageResult() {
		return messageResult;
	}
	public void setMessageResult(String messageResult) {
		this.messageResult = messageResult;
	}
	public String getBillStage() {
		return billStage;
	}
	public void setBillStage(String billStage) {
		this.billStage = billStage;
	}
	public String getReduce() {
		return reduce;
	}
	public void setReduce(String reduce) {
		this.reduce = reduce;
	}
	public String getCardFreeze() {
		return cardFreeze;
	}
	public void setCardFreeze(String cardFreeze) {
		this.cardFreeze = cardFreeze;
	}
	public String getApproveStatus() {
		return approveStatus;
	}
	public void setApproveStatus(String approveStatus) {
		this.approveStatus = approveStatus;
	}
	public String getApproveMemo() {
		return approveMemo;
	}
	public void setApproveMemo(String approveMemo) {
		this.approveMemo = approveMemo;
	}
	public String getApproveTlr() {
		return approveTlr;
	}
	public void setApproveTlr(String approveTlr) {
		this.approveTlr = approveTlr;
	}
	public String getOperatorTlr() {
		return operatorTlr;
	}
	public void setOperatorTlr(String operatorTlr) {
		this.operatorTlr = operatorTlr;
	}
	public String getOpenAlerttime() {
		return openAlerttime;
	}
	public void setOpenAlerttime(String openAlerttime) {
		this.openAlerttime = openAlerttime;
	}
	public String getCloseAlerttime() {
		return closeAlerttime;
	}
	public void setCloseAlerttime(String closeAlerttime) {
		this.closeAlerttime = closeAlerttime;
	}
	public String getReOpenalertTime() {
		return reOpenalertTime;
	}
	public void setReOpenalertTime(String reOpenalertTime) {
		this.reOpenalertTime = reOpenalertTime;
	}
	public String getReClosealertTime() {
		return reClosealertTime;
	}
	public void setReClosealertTime(String reClosealertTime) {
		this.reClosealertTime = reClosealertTime;
	}
	public String getRecStatus() {
		return recStatus;
	}
	public void setRecStatus(String recStatus) {
		this.recStatus = recStatus;
	}
	public String getCheckFlag() {
		return checkFlag;
	}
	public void setCheckFlag(String checkFlag) {
		this.checkFlag = checkFlag;
	}
	public String getRsv1() {
		return rsv1;
	}
	public void setRsv1(String rsv1) {
		this.rsv1 = rsv1;
	}
	public String getRsv2() {
		return rsv2;
	}
	public void setRsv2(String rsv2) {
		this.rsv2 = rsv2;
	}
	public String getRsv3() {
		return rsv3;
	}
	public void setRsv3(String rsv3) {
		this.rsv3 = rsv3;
	}
	public String getRsv4() {
		return rsv4;
	}
	public void setRsv4(String rsv4) {
		this.rsv4 = rsv4;
	}
	public String getRsv5() {
		return rsv5;
	}
	public void setRsv5(String rsv5) {
		this.rsv5 = rsv5;
	}
	public String getRsv6() {
		return rsv6;
	}
	public void setRsv6(String rsv6) {
		this.rsv6 = rsv6;
	}
}
