package com.huateng.hsbc.creditcard.bean;

public class CreditCardProof {
	private String id;
	private String alarmNo;
	private String custNo;
	private String proofName;
	private String proofPath;
	private String status;
	private String getTime;
	private String mainId;
	private String rsv1             ;
	private String rsv2             ;
	private String rsv3             ;
	private String rsv4             ;
	private String rsv5             ;
	private String rsv6             ;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAlarmNo() {
		return alarmNo;
	}
	public void setAlarmNo(String alarmNo) {
		this.alarmNo = alarmNo;
	}
	public String getCustNo() {
		return custNo;
	}
	public void setCustNo(String custNo) {
		this.custNo = custNo;
	}
	public String getProofName() {
		return proofName;
	}
	public void setProofName(String proofName) {
		this.proofName = proofName;
	}
	public String getProofPath() {
		return proofPath;
	}
	public void setProofPath(String proofPath) {
		this.proofPath = proofPath;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getGetTime() {
		return getTime;
	}
	public void setGetTime(String getTime) {
		this.getTime = getTime;
	}
	public String getRsv1() {
		return rsv1;
	}
	public void setRsv1(String rsv1) {
		this.rsv1 = rsv1;
	}
	public String getRsv2() {
		return rsv2;
	}
	public void setRsv2(String rsv2) {
		this.rsv2 = rsv2;
	}
	public String getRsv3() {
		return rsv3;
	}
	public void setRsv3(String rsv3) {
		this.rsv3 = rsv3;
	}
	public String getRsv4() {
		return rsv4;
	}
	public void setRsv4(String rsv4) {
		this.rsv4 = rsv4;
	}
	public String getRsv5() {
		return rsv5;
	}
	public void setRsv5(String rsv5) {
		this.rsv5 = rsv5;
	}
	public String getRsv6() {
		return rsv6;
	}
	public void setRsv6(String rsv6) {
		this.rsv6 = rsv6;
	}
	public String getMainId() {
		return mainId;
	}
	public void setMainId(String mainId) {
		this.mainId = mainId;
	}
}
