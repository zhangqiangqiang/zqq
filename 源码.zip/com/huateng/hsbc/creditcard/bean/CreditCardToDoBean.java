package com.huateng.hsbc.creditcard.bean;

import java.math.BigDecimal;

public class CreditCardToDoBean {
	private String id;
	private String alarmDate;
	private String operatorTlr;
	private String riskLevel;
	private String filed1;
	private String filed2;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAlarmDate() {
		return alarmDate;
	}
	public void setAlarmDate(String alarmDate) {
		this.alarmDate = alarmDate;
	}
	public String getOperatorTlr() {
		return operatorTlr;
	}
	public void setOperatorTlr(String operatorTlr) {
		this.operatorTlr = operatorTlr;
	}
	public String getFiled1() {
		return filed1;
	}
	public void setFiled1(String filed1) {
		this.filed1 = filed1;
	}
	public String getFiled2() {
		return filed2;
	}
	public void setFiled2(String filed2) {
		this.filed2 = filed2;
	}
	public String getRiskLevel() {
		return riskLevel;
	}
	public void setRiskLevel(String riskLevel) {
		this.riskLevel = riskLevel;
	}
}
