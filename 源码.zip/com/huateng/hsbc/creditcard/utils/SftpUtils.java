package com.huateng.hsbc.creditcard.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class SftpUtils {
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	private static Log log = LogFactory.getLog(SftpUtils.class);
	private static String ip;
	private static String port;
	private static String username;
	private static String password;
	private static String prikey;
	
	public SftpUtils(){
		
	}
	
	public SftpUtils(String ip,String port,String username,String password,String prikey){
		this.ip = ip;
		this.port = port;
		this.username = username;
		this.password = password;
		this.prikey = prikey;
	}
	
	public List<String> download(String sftpPath, String localPath,String alermNo) throws Exception {
		log.info("==============================SftpUtil upload start==============================");

		log.info("==============================SftpUtil upload ip["+ ip + "]===============");
		log.info("==============================SftpUtil upload port[" + port + "]=======================");
		log.info("==============================SftpUtil upload username[" + username + "]===============");
		log.info("==============================SftpUtil upload password[" + password + "]===============");
		ChannelSftp sftp = connect(ip, port, username, password,prikey);
		
		List<String> result = new ArrayList<String>();
		Vector<LsEntry> list = sftp.ls(sftpPath);
		for (LsEntry entry : list) {
			String remoteFileName = entry.getFilename();
			log.info("==============================SftpUtil find remoteFileName["+ remoteFileName+ "]===============");
			if (!remoteFileName.equals(".")&& !remoteFileName.equals("..")){
				if(remoteFileName.startsWith(alermNo+"_")){
					result.add(remoteFileName);
					log.info("==============================SftpUtil matching remoteFileName["+ remoteFileName+ "]===============");
				}
			}
		}
		
		FileOutputStream out = null;
		for(String fileName:result){
			sftp.cd(sftpPath);
			File file = new File(localPath + fileName);
			out = new FileOutputStream(file);
			sftp.get(fileName, out);
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					log.error(e.getMessage());
				}
			}
		}
		
		disconnect(sftp);
		
		log.info("==============================SftpUtil download end==============================");
		return result;
	}
	
	public  ChannelSftp connect(String host,String port,String username,String password,String prikey) throws Exception {
	 	log.info("==============================SftpUtil connect start===============");
	 	ChannelSftp sftp = null;
	 	
		JSch jsch = new JSch();
		
		if(CreditCommUtils.isNotEmpty(prikey)&&!"N".equals(prikey)){
			jsch.addIdentity(prikey);
		}
		
		Session sshSession = null;
		if("N".equals(port)||"".equals(port)){
			log.info("==============================SftpUtil connect getSession to ["+host+"]===============");
			sshSession = jsch.getSession(username, host);
		}else{
			log.info("==============================SftpUtil connect getSession to ["+host+"]@["+port+"]===============");
			sshSession = jsch.getSession(username, host, Integer.valueOf(port));
		}
		
		if(password != null&&!"".equals(password)){
			log.info("==============================SftpUtil connect sshSession setPassword ["+password+"]===============");
			sshSession.setPassword(password);  
		}
		sshSession.setTimeout(10000);
		
		Properties sshConfig = new Properties();  
		sshConfig.put("StrictHostKeyChecking", "no");  
		sshSession.setConfig("userauth.gssapi-with-mic", "no");
		sshSession.setConfig("StrictHostKeyChecking", "no");
		sshSession.connect(); 
		log.info("==============================SftpUtil connect sshSession connect success===============");
		Channel channel = sshSession.openChannel("sftp");  
		channel.connect();  
		sftp = (ChannelSftp) channel;
		log.info("==============================SftpUtil connect Channel connect success==================");
        
        return sftp;
    }
	
	public void disconnect(ChannelSftp sftp) {  
		if(sftp != null){  
		    if(sftp.isConnected()){  
		        sftp.disconnect();  
		    }else if(sftp.isClosed()){  
		    	log.info("==============================sftp is closed already===============");
		    }  
		}    
	}
	
	
	public String upload(String sftpPath, String localPath,String fileName){
		log.info("==============================SftpUtil upload start==============================");

		log.info("==============================SftpUtil upload ip["+ ip + "]===============");
		log.info("==============================SftpUtil upload port[" + port + "]=======================");
		log.info("==============================SftpUtil upload username[" + username + "]===============");
		log.info("==============================SftpUtil upload password[" + password + "]===============");
		ChannelSftp sftp;
		try {
			sftp = connect(ip, port, username, password,prikey);
		} catch (Exception e2) {
			log.error("sftp connect失败", e2);
			return "sftp connect失败";
		}
		
		String datePath = sdf.format(new Date());
		sftpPath = sftpPath+datePath+"/";
		
		try {
			sftp.cd(sftpPath);
		} catch (Exception e1) {
			log.info("==============================SftpUtil mkdir[" + datePath + "]===============");
			try {
				sftp.mkdir(sftpPath);
			} catch (SftpException e) {
				log.error("创建日期目录失败", e);
				return "创建日期目录失败";
			}
			try {
				sftp.cd(sftpPath);
			} catch (SftpException e) {
				log.error("进入日期目录失败", e);
				return "进入日期目录失败";
			}
		}
		
		File file = new File(localPath+fileName);
		try {
			sftp.put(new FileInputStream(file), fileName);
//			sftp.chmod(Integer.parseInt("775",8), sftpPath+fileName);
		} catch (Exception e) {
            log.info("==============================SftpUtil connect fail===============");
            log.error("sftp put失败", e);
			return "sftp put失败";
		}finally {
			disconnect(sftp);
		}
		log.info("==============================SftpUtil upload end==============================");
		return null;
	}
	
}
