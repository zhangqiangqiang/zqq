package com.huateng.hsbc.creditcard.utils;

public class CreditConstant {
	public final static String INVESTIGATE_RESULT_01="01";
	public final static String DR="DR";
	public final static String CR="CR";
	
	/*
	 * 状态记录
	 * 	00-未申领
		01-已申领
		02-已处理
		03-自查中
		04-自查审核申领
	 */
	public static enum RecStatus {
		STATUS_00("00"),
		STATUS_01("01"),
		STATUS_02("02"),
		STATUS_03("03"),
		STATUS_04("04");
		
		public String value;
		private RecStatus(String value) {
	        this.value = value;
	    }
		
		public String getValue() {
			return value;
		}
    }
	
	/*
	 * 0-否
	 * 1-是
	 */
	public static enum Flag {
		Flag_0("0"),
		Flag_1("1");
		
		public String value;
		private Flag(String value) {
	        this.value = value;
	    }
		
		public String getValue() {
			return value;
		}
    }
	
	/*
	 * 审核状态
	 * 	01-Critical Error
		02-Non critical Error
		03-Underdiscuss
		04-Pass
	 */
	public static enum ApproveStatus {
		STATUS_01("01","01-Critical Error"),
		STATUS_02("02","02-Non critical Error"),
		STATUS_03("03","03-Underdiscuss"),
		STATUS_04("04","04-Pass");
		
		public String value;
		public String show;
		private ApproveStatus(String value,String show) {
	        this.value = value;
	        this.show = show;
	    }
		
		public static String getShow(String value) {
	        for (ApproveStatus c : ApproveStatus.values()) {
		        if (c.getValue().equals(value)) {
		            return c.show;
		        }
	        }
	        return "";
	    }
		
		public String getValue() {
			return value;
		}
		
		public String geShow() {
			return show;
		}
    }
	
	/*
	 * 	0-待发送
		1-发送中（已生成文件）
		2-发送成功
		3-发送失败
	 */
	public static enum SendStatus {
		STATUS_0("0"),
		STATUS_1("1"),
		STATUS_2("2"),
		STATUS_3("3");
		
		public String value;
		private SendStatus(String value) {
	        this.value = value;
	    }
		
		public String getValue() {
			return value;
		}
    }
	
	public static enum ReportFieldType {
		VARCHAR2("VARCHAR2"),
		DATADIC("DATADIC"),
		BIGDECIMAL("BIGDECIMAL"),
		DATETIME("DATETIME"),
		NUMBER("NUMBER");
		
		public String value;
		private ReportFieldType(String value) {
	        this.value = value;
	    }
		
		public String getValue() {
			return value;
		}
    }
	/*
	 * 	01-调查中
		11-F(白名单)
		12-F(凭证通过)
		13-F(外呼凭证通过)
		14-F(外呼通过)
		21-T(凭证未通过)
		22-T(外呼凭证未通过)
		23-T(外呼未通过)
		24-T(无法判断)
		31-A(关注)
		91-无需调查
		00-ALL
	 */
	public static enum InvestigateResult{
		RESULT_00("00"),
		RESULT_01("01");
		
		public String value;
		private InvestigateResult(String value) {
	        this.value = value;
	    }
		
		public String getValue() {
			return value;
		}
	}
}
