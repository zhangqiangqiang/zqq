package com.huateng.hsbc.creditcard.job;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.huateng.ebank.framework.exceptions.CommonException;

public class AutoExtractJob implements org.quartz.Job{
	
	private static Log log = LogFactory.getLog(AutoExtractJob.class);
	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		
		log.info("AutoExtractJob begin");
		AutoExtractService service = new AutoExtractService();
		try {
			service.extract();
		} catch (CommonException e) {
			log.error("AutoExtractJob error", e);
		}
		log.info("AutoExtractJob end");
	}

}
