package com.huateng.hsbc.creditcard.job;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.exceptions.CommonException;
import com.huateng.excel.imp.DataMyUtil;
import com.huateng.hsbc.creditcard.bean.CreditCardAlert;
import com.huateng.hsbc.creditcard.bean.CreditCardMsg;
import com.huateng.hsbc.creditcard.bean.SendAgentSystem;
import com.huateng.hsbc.creditcard.utils.CreditCommUtils;
import com.huateng.hsbc.creditcard.utils.CreditConstant;
import com.huateng.hsbc.creditcard.utils.SftpUtils;
import com.huateng.report.utils.ReportUtils;

public class GenerateMsgFileService {
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	private static SimpleDateFormat sdf_time = new SimpleDateFormat("yyyyMMddHHmmss");
	private static Log log = LogFactory.getLog(GenerateMsgFileService.class);
	
	public void generateMsgFile() throws CommonException{
		String today = sdf.format(new Date());
		ROOTDAO rootDao= ROOTDAOUtils.getROOTDAO();
		String lpath = ReportUtils.getSysParamsValue("MSG", "LPATH");
		String ip = ReportUtils.getSysParamsValue("MSG", "IP");
		String port = ReportUtils.getSysParamsValue("MSG", "PORT");
		String username = ReportUtils.getSysParamsValue("MSG", "USERNAME");
		String pwd = ReportUtils.getSysParamsValue("MSG", "PASSWORD");
		String prikey = ReportUtils.getSysParamsValue("MSG", "PRIKEY");
		String path = ReportUtils.getSysParamsValue("MSG", "PATH");
		String bankNo = ReportUtils.getSysParamsValue("MSG", "BANKNO");
		String lastWorkDate = CreditCommUtils.getLastWorkDate(rootDao);
		boolean isWorkDate = CreditCommUtils.isWorkDate(rootDao, today);
		
		String fileName = bankNo + "-OTHER-" + today + "-41" + ".TXT";
		String filePath = lpath + fileName;
		
		log.info("isWorkDate:"+isWorkDate);
		log.info("lastWorkDate:"+lastWorkDate);
		log.info("bankNo:"+bankNo);
		log.info("fileName:"+fileName);
		List<CreditCardMsg> msgs = null;
		if(isWorkDate){
			StringBuffer hql = new StringBuffer("from CreditCardMsg where ");
			hql.append(" saveTime>='").append(lastWorkDate+"000000").append("' ");
			hql.append(" and saveTime<='").append(lastWorkDate+"235959").append("' ");
//			hql.append(" and status='").append(CreditConstant.SendStatus.STATUS_0.getValue()).append("'");
			msgs = rootDao.queryByQL2List(hql.toString());
		}else{
			msgs = new ArrayList<CreditCardMsg>();
		}
		//生成文件
		boolean flag = writeTxt(msgs,filePath);
		log.info("flag:"+flag);
		if(flag){
			for(CreditCardMsg msg : msgs){
				msg.setStatus(CreditConstant.SendStatus.STATUS_1.getValue());
				rootDao.saveOrUpdate(msg);
			}
			
			SftpUtils sftp = new SftpUtils(ip,port,username,pwd,prikey);
			String ret = sftp.upload(path, lpath, fileName);
			log.info("ret:"+ret);
			
			SendAgentSystem sas = null;
			if(ret==null){//sftp 成功
				for(CreditCardMsg msg : msgs){
					msg.setStatus(CreditConstant.SendStatus.STATUS_2.getValue());
					msg.setSendTime(sdf_time.format(new Date()));
					rootDao.saveOrUpdate(msg);
				}
				
				//删除当天坐席报表信息
				StringBuffer delSql = new StringBuffer("delete from SEND_AGENT_SYSTEM where REPORT_DATE='"+today+"'");
				rootDao.executeSql(delSql.toString());
				log.info("delSql:"+delSql.toString());
				//生产坐席报表信息
				for(CreditCardMsg msg : msgs){
					if(CreditConstant.SendStatus.STATUS_2.getValue().equals(msg.getStatus())){
						sas = new SendAgentSystem();
						//主键
						sas.setRec_id(new BigDecimal(rootDao.queryListBySql("select send_agent_system_seq.NEXTVAL from DUAL").get(0).toString()));
						//查询告警号对应的记录
	                    ArrayList<String> condList = new ArrayList<String>();
	    				condList.add(msg.getAlarmNo());
	                    List<CreditCardAlert> taskList = rootDao.queryByCondition("from CreditCardAlert where 1=1 and alarmNo = ?", condList.toArray());
	                    CreditCardAlert cca = taskList.get(0);
	                    //告警日期
	                    sas.setAlarm_date(cca.getAlarmDate());
	                    sas.setCust_cert_no(cca.getCustCertno());
	                    sas.setCust_cert_type(cca.getCustCerttype());
	                    sas.setService_name(cca.getAlarmDate()+"encashment");
	                    sas.setService_comment(msg.getServerInfo()+"于"+today+"发送信息："+msg.getMsgInfo());
	                    sas.setReport_date(today);
	                    rootDao.saveOrUpdate(sas);
//	                    sas.setService_comment(msg.getServerInfo()+"于"+msg.getSendTime()+"发送信息："+msg.getMsgInfo());
//	                    sas.setService_name(cca.getAlarmDate().substring(0, 4)+"/"+cca.getAlarmDate().substring(4, 6)+"/"+cca.getAlarmDate().substring(6, 8));
//	                    sas.setService_comment(msg.getServerInfo()+"于"+msg.getSendTime().substring(0,4)+"/"+msg.getSendTime().substring(4,6)+"/"+msg.getSendTime().substring(6,8)+"发送信息："+msg.getMsgInfo());
					}
				}
			}else{//sftp 失败
				for(CreditCardMsg msg : msgs){
					msg.setStatus(CreditConstant.SendStatus.STATUS_3.getValue());
					rootDao.saveOrUpdate(msg);
				}
			}
		}
	}
	
	private boolean writeTxt(List<CreditCardMsg> msgs,String filePath){
		File file = new File(filePath);
		FileOutputStream fos = null;
		String newLine = "\r\n";
		try {
			if(!file.exists()) {
				file.createNewFile();
			}else {
				file.delete();
				file.createNewFile();
			}
			fos =  new FileOutputStream (filePath,false);
			if(msgs!=null){
				for(int i=0;i<msgs.size();i++){
					CreditCardMsg msg = msgs.get(i);
					String show = msg.getPhoneNo()+" "+msg.getMsgInfo();
					fos.write(show.getBytes("GB2312"));
					fos.write(newLine.getBytes("GB2312"));
				}
			}
			fos.flush();
			return true;
		}catch(Exception e){
			return false;
		}finally{
			if(fos!=null){
				try {
					fos.close();
				} catch (IOException e) {
					
				}
			}
		}
	}
}
