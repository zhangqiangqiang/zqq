package com.huateng.hsbc.creditcard.job;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.huateng.ebank.framework.exceptions.CommonException;

public class GenerateMsgFileJob implements org.quartz.Job{
	
	private static Log log = LogFactory.getLog(GenerateMsgFileJob.class);
	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		// TODO Auto-generated method stub
//		Calendar c = Calendar.getInstance();
//		c.add(Calendar.DATE, -1);
//		String date = sdf.format(c.getTime());
		
		log.info("GenerateMsgFileJob begin");
		GenerateMsgFileService service = new GenerateMsgFileService();
		try {
			service.generateMsgFile();
		} catch (CommonException e) {
			log.error("GenerateMsgFileJob error", e);
		}
		log.info("GenerateMsgFileJob end");
	}

}
