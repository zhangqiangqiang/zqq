package com.huateng.hsbc.creditcard.job;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.exceptions.CommonException;
import com.huateng.hsbc.creditcard.bean.CreditCardAlert;
import com.huateng.hsbc.creditcard.utils.CreditCommUtils;
import com.huateng.hsbc.creditcard.utils.CreditConstant;
import com.huateng.report.utils.ReportUtils;

public class AutoExtractService {
	private static Log log = LogFactory.getLog(AutoExtractService.class);
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	
	public void extract() throws CommonException{
		ROOTDAO rootDao= ROOTDAOUtils.getROOTDAO();
		String flag = ReportUtils.getSysParamsValue("ALERT", "FLAG");
		if(!"Y".equals(flag)){
			log.info("SysParam alert flag is not Y,return !");
			return;
		}
		
		String today = sdf.format(new Date());
		log.info("today:"+today);
		if(!CreditCommUtils.isWorkDate(rootDao, today)){
			log.info("today is not workDate,return!");
			return;
		}
		
		String percentStr = ReportUtils.getSysParamsValue("ALERT", "PERCENT");
		String showDay = ReportUtils.getSysParamsValue("ALERT", "SHOWDAY");
		BigDecimal percent = new BigDecimal(percentStr).divide(new BigDecimal(100));
		if(percent.compareTo(new BigDecimal(1))==1){
			percent = new BigDecimal(1);
		}
		String limit = CreditCommUtils.getLimitWorkDateForAutoExtract(rootDao);
		
		log.info("showDay:"+showDay);
		log.info("today-showDay>>limit:"+limit);
		
		//时间
		StringBuffer condition_limit = new StringBuffer();
		condition_limit.append(" AND a.CLOSE_ALERT_TIME >= '").append(limit+"0000").append("'");
		condition_limit.append(" AND a.CLOSE_ALERT_TIME <= '").append(limit+"2359").append("'");
		//recstatus=02
		StringBuffer condition_recStatus = new StringBuffer();
		condition_recStatus.append(" WHERE a.REC_STATUS='").append(CreditConstant.RecStatus.STATUS_02.getValue()).append("'");
		//checkFlag=1
		StringBuffer condition_checkFlag_1 = new StringBuffer();
		condition_checkFlag_1.append(" AND a.CHECK_FLAG = '").append(CreditConstant.Flag.Flag_1.getValue()).append("'");
		////checkFlag=0
		StringBuffer condition_checkFlag_0 = new StringBuffer();
		condition_checkFlag_0.append(" AND a.CHECK_FLAG = '").append(CreditConstant.Flag.Flag_0.getValue()).append("'");
		log.info("running batch begin");
		//查出所有的batch
		StringBuffer sql_all_batch = new StringBuffer();
		sql_all_batch.append(" SELECT DISTINCT a.ALARM_DATE from CREDIT_CARD_ALERT a");
		sql_all_batch.append(condition_recStatus);
		sql_all_batch.append(condition_limit);
		sql_all_batch.append(condition_checkFlag_0);
		Iterator iterator_batch = rootDao.queryBySQL2(sql_all_batch.toString());
		while(iterator_batch.hasNext()){
			Map map_batch = (Map) iterator_batch.next();
			String alarmDate = (String)map_batch.get("ALARM_DATE");
			log.info("alarmDate:"+alarmDate);
			//查出当前所有的操作员号
			StringBuffer sql_all_operator = new StringBuffer();
			sql_all_operator.append(" SELECT DISTINCT a.OPERATOR_TLR from CREDIT_CARD_ALERT a");
			sql_all_operator.append(condition_recStatus);
			sql_all_operator.append(condition_limit);
			sql_all_operator.append(condition_checkFlag_0);
			sql_all_operator.append(" AND a.ALARM_DATE = '").append(alarmDate).append("'");
			Iterator iterator_operator = rootDao.queryBySQL2(sql_all_operator.toString());
			
			while(iterator_operator.hasNext()){
				Map map_operator = (Map) iterator_operator.next();
				String operator = (String)map_operator.get("OPERATOR_TLR");
				log.info("operator:"+operator);
				
				StringBuffer sql_operator_alert = new StringBuffer();
				sql_operator_alert.append("select count(1) from CREDIT_CARD_ALERT a ");
				sql_operator_alert.append(" WHERE CLOSE_ALERT_TIME IS NOT NULL ");//完成的
				sql_operator_alert.append(" AND OPERATOR_TLR = '").append(operator).append("'");
				sql_operator_alert.append(" AND a.ALARM_DATE = '").append(alarmDate).append("'");
				sql_operator_alert.append(" AND a.CLOSE_ALERT_TIME <= '").append(limit+"2359").append("'");
				int count_operator_do = rootDao.queryBySqlToCount(sql_operator_alert.toString());
				log.info("count_operator_do:"+count_operator_do);
				
				StringBuffer sql_operator_check = new StringBuffer();
				sql_operator_check.append("select count(1) from CREDIT_CARD_ALERT a ");
				sql_operator_check.append(" WHERE OPERATOR_TLR = '").append(operator).append("'");
				sql_operator_check.append(" AND a.ALARM_DATE = '").append(alarmDate).append("'");
				sql_operator_alert.append(" AND a.CLOSE_ALERT_TIME <= '").append(limit+"2359").append("'");
				sql_operator_check.append(" AND a.CHECK_FLAG = '").append(CreditConstant.Flag.Flag_1.getValue()).append("'");
				int count_operator_check = rootDao.queryBySqlToCount(sql_operator_check.toString());
				log.info("count_operator_check:"+count_operator_check);
				
				BigDecimal all_need_check = new BigDecimal(count_operator_do).multiply(percent).setScale(0,BigDecimal.ROUND_UP);
				log.info("all_need_check:"+all_need_check);
				if(all_need_check.compareTo(new BigDecimal(count_operator_check))==0){
					log.info("count_need_check=count_operator_check 不需要抽取");
				}else{
					BigDecimal need_check = all_need_check.subtract(new BigDecimal(count_operator_check));
					log.info("需要抽取数量:"+need_check);
					
					StringBuffer hql_no_check = new StringBuffer("from CreditCardAlert a");
					hql_no_check.append(" where a.recStatus='").append(CreditConstant.RecStatus.STATUS_02.getValue()).append("'");
					hql_no_check.append(" and a.operatorTlr = '").append(operator).append("'");
					hql_no_check.append(" AND a.alarmDate = '").append(alarmDate).append("'");
//					hql_no_check.append(" AND a.closeAlerttime >= '").append(limit+"0000").append("'");
					hql_no_check.append(" AND a.closeAlerttime <= '").append(limit+"2359").append("'");
					hql_no_check.append(" AND a.checkFlag = '").append(CreditConstant.Flag.Flag_0.getValue()).append("'");
					List<CreditCardAlert> noCheckResult = rootDao.queryByQL2List(hql_no_check.toString());
					log.info("从"+noCheckResult.size()+"条Alert中随机抽取");
					
					List<Integer> indexs = CreditCommUtils.getRandomIndex(noCheckResult.size(), need_check.intValue());
					log.info("抽取"+indexs.size()+"条Alert");
					for(Integer index : indexs){
						CreditCardAlert alert = noCheckResult.get(index);
						alert.setRecStatus(CreditConstant.RecStatus.STATUS_03.getValue());
						alert.setCheckFlag(CreditConstant.Flag.Flag_1.getValue());
						alert.setRsv1("1");//自动抽查
						rootDao.update(alert);
					}
				}
			}
		}
		log.info("running batch end");
	}
}
