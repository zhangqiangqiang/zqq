package com.huateng.hsbc.creditcard.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.ui.ModelMap;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.exceptions.CommonException;
import com.huateng.excel.imp.DataMyUtil;
import com.huateng.hsbc.creditcard.bean.CreditCardAlert;
import com.huateng.hsbc.creditcard.bean.CreditCardAuditTrail;
import com.huateng.hsbc.creditcard.bean.CreditCardProof;
import com.huateng.hsbc.creditcard.utils.CreditCommUtils;
import com.huateng.hsbc.creditcard.utils.CreditConstant;
import com.huateng.hsbc.cust.bean.CustUploadFileInfo;
import com.huateng.report.aml.feedback.service.AmlFeedBackservice;
import com.huateng.report.utils.ReportUtils;

public class ProofUploadController extends MultiActionController {
	protected Logger logger = Logger.getLogger(getClass());

	protected String result;// 结果返回页面

	protected CommonsMultipartResolver multipartResolver;// 文件上传

	public void setResult(String result) {
		this.result = result;
	}

	public String getResult() {
		return result;
	}

	public void setMultipartResolver(CommonsMultipartResolver multipartResolver) {
		this.multipartResolver = multipartResolver;
	}

	public CommonsMultipartResolver getMultipartResolver() {
		return multipartResolver;
	}

	/*
	 * 凭证导入
	 */
	@SuppressWarnings({ "unused", "deprecation", "unchecked", "rawtypes" })
	public ModelAndView uploadProofFile(HttpServletRequest request,HttpServletResponse reponse) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		SimpleDateFormat sdf_ymd = new SimpleDateFormat("yyyyMMdd");
		ROOTDAO rootDao= ROOTDAOUtils.getROOTDAO();
		File uploadFile = null;
		MultipartResolver resolver = new CommonsMultipartResolver(request.getSession().getServletContext());
		MultipartHttpServletRequest mrequest = resolver.resolveMultipart(request);
		mrequest.setCharacterEncoding("UTF-8");
		HttpSession httpSession = request.getSession();
		GlobalInfo globalInfo = (GlobalInfo) httpSession.getAttribute(GlobalInfo.KEY_GLOBAL_INFO);
		GlobalInfo.setCurrentInstance(globalInfo);
		// 封装页面返回对象
		List errorList = new ArrayList();
		ModelMap mmap = new ModelMap();
		mmap.addObject("errors", errorList);
		ModelAndView modelAndView = new ModelAndView(result, mmap);
		// 验证上传的文件大小限制？
		try {
			String time = sdf.format(new Date());
			String path = ReportUtils.getSysParamsValue("PROOF", "LPATH");
			String msgid = mrequest.getParameter("msgid");
			CreditCardAlert alert = rootDao.query(CreditCardAlert.class, msgid);
			String alarmDate = alert.getAlarmDate();
			path = path + alarmDate + File.separator;
			mkdirIfNotExists(path);
			String fileNamePrefix = alert.getAlarmNo() + "_" +sdf_ymd.format(new Date())+ "_";
			
			StringBuffer sql_count = new StringBuffer();
			sql_count.append("select count(1) from CREDIT_CARD_PROOF a ");
			sql_count.append(" where a.MAIN_ID='").append(msgid).append("'");
			int count = rootDao.queryBySqlToCount(sql_count.toString());
			
			List<MultipartFile> files = mrequest.getFiles("uploadFile");
			for(MultipartFile file:files){
				String originalName = file.getOriginalFilename();
				String fileNameSuffix = originalName.substring(originalName.lastIndexOf("."), originalName.length());
				String fileName;
				if(count<10){
					fileName = fileNamePrefix+"00"+(count++) + fileNameSuffix;
				}else if(count<100){
					fileName = fileNamePrefix+"0"+(count++) + fileNameSuffix;
				}else{
					fileName = fileNamePrefix+(count++) + fileNameSuffix;
				}
				uploadFile = new File(path+fileName);
	            file.transferTo(uploadFile);
	            
	            CreditCardProof proof = new CreditCardProof();
	            proof.setId(CreditCommUtils.getUUID());
	            proof.setAlarmNo(alert.getAlarmNo());
	            proof.setProofName(fileName);
	            proof.setProofPath(path);
	            proof.setStatus(CreditConstant.Flag.Flag_0.getValue());
	            proof.setGetTime(time);
	            proof.setMainId(msgid);
	            rootDao.save(proof);
	            
	            //Audit
	            CreditCardAuditTrail audit = new CreditCardAuditTrail();
				audit.setId(CreditCommUtils.getUUID());
				audit.setAlarmNo(alert.getAlarmNo());
				audit.setFieldName("凭证文件");
				audit.setOldValue(fileName);
				audit.setNewValue("上传");
				GlobalInfo gi = GlobalInfo.getCurrentInstance();
				audit.setOperatorTlr(gi.getTlrno());
				audit.setOperatorTime(sdf.format(new Date()));
				rootDao.save(audit);
			}
		} catch (Exception e) {
			e.printStackTrace();
			errorList.add("系统内部出错，错误信息：" + e.toString());
		}
		return modelAndView;
	}
	
	/*
	 * 下载凭证
	 */
    public ModelAndView downloadProofFile(HttpServletRequest request,HttpServletResponse response) throws Exception {
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
    	ROOTDAO rootDao= ROOTDAOUtils.getROOTDAO();
    	HttpSession httpSession = request.getSession();
		GlobalInfo globalInfo = (GlobalInfo) httpSession.getAttribute(GlobalInfo.KEY_GLOBAL_INFO);
		GlobalInfo.setCurrentInstance(globalInfo);
    	// 封装页面返回对象
		List errorList = new ArrayList();
		ModelMap mmap = new ModelMap();
		mmap.addAttribute("errors", errorList);
		ModelAndView modelAndView = new ModelAndView(result,mmap);
		
		String downloadinfo = request.getParameter("downloadinfo");
		if("proof".equals(downloadinfo)) {
			String proofId = request.getParameter("proofId");
			CreditCardProof proof = rootDao.query(CreditCardProof.class, proofId);
			
			String filePath = proof.getProofPath() + proof.getProofName();
			
			BufferedInputStream bis = null;
			BufferedOutputStream bos = null;

			try {
				response.setContentType("application/x-msdownload");
				response.setHeader("Content-disposition","attachment;filename="+ URLEncoder.encode(proof.getProofName(), "UTF-8"));// 进行编码

				bis = new BufferedInputStream(new FileInputStream(filePath));
				bos = new BufferedOutputStream(response.getOutputStream());
				byte[] buff = new byte[2048];
				int bytesRead;
				while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
					bos.write(buff, 0, bytesRead);
				}
			} catch (Exception e) {
				errorList.add("系统内部出错：" + e.toString());
			} finally {
				try {
					if (bis != null) {
						bis.close();
					}
					if (bos != null) {
						bos.close();
					}
				} catch (IOException e2) {
					errorList.add("系统内部出错：" + e2.toString());
				}
			}
		}
		
		if(errorList.size() > 0)
			return modelAndView;
		return null;
    }
	
	/**
	 * 文件目录不存在则创建文件目录，带层级
	 * 
	 * @param path
	 */
	private void mkdirIfNotExists(String path) {
		File file = new File(path);
		if (!file.exists()) {
			file.mkdirs();
		}
	}
}
